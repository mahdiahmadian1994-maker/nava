package com.mrahmadiaan.nava.ui

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Process
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId

val weekdayNames = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
val monthNames = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

fun fa(s: Any): String = s.toString().map { if (it in '0'..'9') ('۰' + (it - '0')) else it }.joinToString("")

private val ones = listOf(
    "صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده", "یازده", "دوازده",
    "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"
)
private val tens = listOf("", "", "بیست", "سی", "چهل", "پنجاه")

fun numWord(n: Int): String = when {
    n < 20 -> ones[n]
    n % 10 == 0 -> tens[n / 10]
    else -> tens[n / 10] + " و " + ones[n % 10]
}

fun timeWords(h: Int, m: Int): String =
    if (m == 0) "ساعت ${numWord(h)}" else "ساعت ${numWord(h)} و ${numWord(m)} دقیقه"

fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
    var jy = -1595 + (33 * (days / 12053))
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
    val jd = 1 + (if (days < 186) days % 31 else (days - 186) % 30)
    return Triple(jy, jm, jd)
}

fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
    val jy2 = jy + 1595
    var days = -355668 + (365 * jy2) + ((jy2 / 33) * 8) + (((jy2 % 33) + 3) / 4) + jd +
        (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
    var gy = 400 * (days / 146097)
    days %= 146097
    if (days > 36524) {
        days--
        gy += 100 * (days / 36524)
        days %= 36524
        if (days >= 365) days++
    }
    gy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        gy += (days - 1) / 365
        days = (days - 1) % 365
    }
    var gd = days + 1
    val leap = (gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)
    val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    var gm = 0
    while (gm < 13 && gd > sal[gm]) {
        gd -= sal[gm]
        gm++
    }
    return Triple(gy, gm, gd)
}

fun jalaliMonthLength(jy: Int, jm: Int): Int = when {
    jm <= 6 -> 31
    jm <= 11 -> 30
    else -> {
        val g = jalaliToGregorian(jy, 12, 30)
        if (gregorianToJalali(g.first, g.second, g.third) == Triple(jy, 12, 30)) 30 else 29
    }
}

/** شنبه = 0 ... جمعه = 6 */
fun weekdayIndex(d: LocalDate): Int = (d.dayOfWeek.value + 1) % 7

fun hasPerm(ctx: Context, p: String): Boolean =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

suspend fun httpGet(url: String): String? = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "NavaLauncher/1.0")
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }
}

data class Weather(val temp: Double, val wind: Double, val dir: Double, val code: Int, val isDay: Boolean)

suspend fun fetchWeather(lat: Double, lon: Double): Weather? {
    val t = httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true")
        ?: return null
    return try {
        val c = JSONObject(t).getJSONObject("current_weather")
        Weather(
            c.getDouble("temperature"), c.getDouble("windspeed"), c.getDouble("winddirection"),
            c.getInt("weathercode"), c.optInt("is_day", 1) == 1
        )
    } catch (e: Exception) {
        null
    }
}

fun weatherInfo(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "آسمان صاف"
    1, 2 -> "⛅" to "نیمه‌ابری"
    3 -> "☁️" to "ابری"
    45, 48 -> "🌫️" to "مه"
    in 51..57 -> "🌦️" to "نم‌نم باران"
    in 61..67 -> "🌧️" to "باران"
    in 71..77 -> "❄️" to "برف"
    in 80..82 -> "🌧️" to "رگبار"
    in 95..99 -> "⛈️" to "رعد و برق"
    else -> "🌡️" to "نامشخص"
}

fun bestLocation(ctx: Context): Pair<Double, Double> {
    val la = NavaStore.lastLat
    val lo = NavaStore.lastLon
    if (la != null && lo != null) return la to lo
    if (hasPerm(ctx, Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)) {
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                val l = lm.getLastKnownLocation(p)
                if (l != null) return l.latitude to l.longitude
            }
        } catch (e: SecurityException) {
        }
    }
    return 35.6892 to 51.3890
}

fun batteryPercent(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    return if (l < 0) -1 else l * 100 / s
}

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

suspend fun loadApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(i, 0)
        .mapNotNull { r ->
            try {
                AppInfo(
                    r.loadLabel(pm).toString(),
                    r.activityInfo.packageName,
                    r.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
                )
            } catch (e: Exception) {
                null
            }
        }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun openApp(ctx: Context, pkg: String) {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

fun usageToday(ctx: Context): Map<String, Long> {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val m = usm.queryAndAggregateUsageStats(start, System.currentTimeMillis())
    return m.mapValues { it.value.totalTimeInForeground }.filter { it.value > 0L }
}
