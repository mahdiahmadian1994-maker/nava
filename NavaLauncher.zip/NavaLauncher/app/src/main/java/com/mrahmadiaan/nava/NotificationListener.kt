package com.mrahmadiaan.nava

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        val allowedApp = NavaStore.allowed.contains(pkg)

        Handler(Looper.getMainLooper()).post {
            if (NavaStore.tracking) NavaStore.addEventHere("notif", "$label: $title")
            if (allowedApp) {
                NavaStore.addMessage(MsgItem(pkg, label, title, text, n.contentIntent, reply))
            }
        }
    }
}
