package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import java.time.LocalDate

@Composable
fun CalendarScreen(nav: NavController) {
    val today = LocalDate.now()
    val tj = gregorianToJalali(today.year, today.monthValue, today.dayOfMonth)
    var jy by remember { mutableStateOf(tj.first) }
    var jm by remember { mutableStateOf(tj.second) }
    var selected by remember { mutableStateOf(tj.third) }

    val fg = jalaliToGregorian(jy, jm, 1)
    val firstIdx = weekdayIndex(LocalDate.of(fg.first, fg.second, fg.third))
    val len = jalaliMonthLength(jy, jm)
    val cells = List(firstIdx) { 0 } + (1..len).toList()
    val rows = cells.chunked(7)
    val key = "$jy-$jm-$selected"
    val items = remember(key) { mutableStateListOf<String>().apply { addAll(NavaStore.getChecklist(key)) } }
    var newItem by remember { mutableStateOf("") }

    ScreenFrame("تقویم جلالی", nav) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                if (jm == 12) { jm = 1; jy += 1 } else jm += 1
                selected = 1
            }) { Text("‹ بعد") }
            Text("${monthNames[jm - 1]} ${fa(jy)}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = {
                if (jm == 1) { jm = 12; jy -= 1 } else jm -= 1
                selected = 1
            }) { Text("قبل ›") }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth()) {
                for (n in listOf("ش", "ی", "د", "س", "چ", "پ", "ج")) {
                    Text(n, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                }
            }
            for (row in rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0 until 7) {
                        val d = row.getOrNull(i) ?: 0
                        val isToday = d != 0 && jy == tj.first && jm == tj.second && d == tj.third
                        val bg = when {
                            d == 0 -> Color.Transparent
                            isToday -> Pal.orange
                            i == 6 -> Pal.green
                            else -> Color.White.copy(alpha = 0.7f)
                        }
                        val ring = if (d != 0 && d == selected) Pal.navy.copy(alpha = 0.6f) else Color.Transparent
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ring)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(bg)
                                .clickable(enabled = d != 0) { selected = d },
                            contentAlignment = Alignment.Center
                        ) {
                            if (d != 0) Text(fa(d), color = if (isToday) Color.White else Pal.navy, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("چک‌لیست ${fa(selected)} ${monthNames[jm - 1]}", fontWeight = FontWeight.Bold)
            for ((idx, raw) in items.toList().withIndex()) {
                val done = raw.startsWith("1|")
                val label = raw.drop(2)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = done, onCheckedChange = {
                        items[idx] = (if (it) "1|" else "0|") + label
                        NavaStore.setChecklist(key, items)
                    })
                    Text(label, Modifier.weight(1f))
                    TextButton(onClick = {
                        items.removeAt(idx)
                        NavaStore.setChecklist(key, items)
                    }) { Text("حذف") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newItem, onValueChange = { newItem = it },
                    singleLine = true, placeholder = { Text("یادآور / کار جدید") },
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    if (newItem.isNotBlank()) {
                        items.add("0|" + newItem.trim())
                        NavaStore.setChecklist(key, items)
                        newItem = ""
                    }
                }) { Text("افزودن") }
            }
        }
    }
}
