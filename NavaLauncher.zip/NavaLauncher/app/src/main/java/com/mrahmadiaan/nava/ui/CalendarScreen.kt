package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import java.time.LocalDate

// هر آیتم: "done|HH:mm|HH:mm|title"
private class Task(val done: Boolean, val from: String, val to: String, val title: String) {
    fun enc(): String = (if (done) "1" else "0") + "|" + from + "|" + to + "|" + title.replace("|", " ")
}

private fun parseTask(s: String): Task {
    val p = s.split("|", limit = 4)
    return if (p.size == 4) Task(p[0] == "1", p[1], p[2], p[3]) else Task(false, "", "", s)
}

private val timeRe = Regex("^\\d{1,2}:\\d{2}$")

@Composable
fun CalendarScreen(nav: NavController) {
    val today = LocalDate.now()
    val tj = gregorianToJalali(today.year, today.monthValue, today.dayOfMonth)
    var jy by remember { mutableStateOf(tj.first) }
    var jm by remember { mutableStateOf(tj.second) }
    var selected by remember { mutableStateOf(tj.third) }
    var ver by remember { mutableStateOf(0) }
    var newTitle by remember { mutableStateOf("") }
    var tFrom by remember { mutableStateOf("") }
    var tTo by remember { mutableStateOf("") }
    val pal = PaletteState.colors

    val fg = jalaliToGregorian(jy, jm, 1)
    val firstIdx = weekdayIndex(LocalDate.of(fg.first, fg.second, fg.third))
    val len = jalaliMonthLength(jy, jm)
    val rows = (List(firstIdx) { 0 } + (1..len).toList()).chunked(7)
    val key = "$jy-$jm-$selected"
    val items = remember(key) { mutableStateListOf<String>().apply { addAll(NavaStore.getChecklist(key)) } }

    fun save() {
        NavaStore.setChecklist(key, items)
        ver++
    }

    val tasks = items.map { parseTask(it) }
    val doneCount = tasks.count { it.done }

    ScreenFrame(tr("تقویم", "Calendar"), nav) {
        // نوار آمار شیشه‌ای (مثل نمونه)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fa(tasks.size), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(tr("کارها", "Tasks"), fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fa(doneCount), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(tr("انجام‌شده", "Done"), fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fa(tasks.size - doneCount), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(tr("باقی‌مانده", "Left"), fontSize = 11.sp)
                }
            }
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton("back", MaterialTheme.colorScheme.onBackground, {
                    if (jm == 1) { jm = 12; jy -= 1 } else jm -= 1
                    selected = 1
                }, 36)
                Text("${monthNames[jm - 1]} ${fa(jy)}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.size(36.dp).clickable {
                    if (jm == 12) { jm = 1; jy += 1 } else jm += 1
                    selected = 1
                }, contentAlignment = Alignment.Center) {
                    // فلش جهت مخالف
                    Text(if (Lang.fa) "‹" else "›", fontSize = 26.sp)
                }
            }
            Gap(6)
            Row(Modifier.fillMaxWidth()) {
                val names = if (Lang.fa) listOf("ش", "ی", "د", "س", "چ", "پ", "ج") else listOf("S", "S", "M", "T", "W", "T", "F")
                for (n in names) Text(n, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            for (row in rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0 until 7) {
                        val d = row.getOrNull(i) ?: 0
                        val isToday = d != 0 && jy == tj.first && jm == tj.second && d == tj.third
                        val count = if (d != 0 && ver >= 0) NavaStore.getChecklist("$jy-$jm-$d").size else 0
                        val bg = when {
                            d == 0 -> Color.Transparent
                            isToday -> pal[4]
                            i == 6 -> pal[0].copy(alpha = 0.7f)
                            count > 0 -> pal[1].copy(alpha = 0.35f)
                            else -> Color.White.copy(alpha = 0.25f)
                        }
                        val ring = if (d != 0 && d == selected) Modifier.border(2.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f), RoundedCornerShape(14.dp)) else Modifier
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(bg)
                                .then(ring)
                                .clickable(enabled = d != 0) { selected = d },
                            contentAlignment = Alignment.Center
                        ) {
                            if (d != 0) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(fa(d), fontSize = 14.sp, color = if (isToday) Color.White else MaterialTheme.colorScheme.onBackground)
                                    if (count > 0) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            for (x in 0 until minOf(count, 3)) {
                                                Box(Modifier.size(4.dp).clip(CircleShape).background(pal[2]))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Gap(10)
        // چک‌لیست و افزودن به اسکجولر
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("برنامه ${fa(selected)} ${monthNames[jm - 1]}", "Plan: ${selected} ${monthNames[jm - 1]}"), fontWeight = FontWeight.Bold)
            for ((idx, t) in tasks.withIndex()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = t.done, onCheckedChange = {
                        items[idx] = Task(it, t.from, t.to, t.title).enc()
                        save()
                    })
                    Column(Modifier.weight(1f)) {
                        Text(t.title)
                        if (t.from.isNotEmpty()) Text(fa("${t.from} - ${t.to}"), fontSize = 11.sp)
                    }
                    GlassIconButton("trash", pal[2], { items.removeAt(idx); save() }, 34)
                }
            }
            Gap(6)
            OutlinedTextField(
                value = newTitle, onValueChange = { newTitle = it }, singleLine = true,
                placeholder = { Text(tr("عنوان کار / یادآور", "Task / reminder")) },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = tFrom, onValueChange = { tFrom = it }, singleLine = true,
                    placeholder = { Text("09:00") }, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = tTo, onValueChange = { tTo = it }, singleLine = true,
                    placeholder = { Text("10:30") }, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    if (newTitle.isNotBlank()) {
                        val f = if (timeRe.matches(tFrom.trim())) tFrom.trim() else ""
                        val e = if (f.isNotEmpty() && timeRe.matches(tTo.trim())) tTo.trim() else ""
                        items.add(Task(false, f, e, newTitle.trim()).enc())
                        val sorted = items.sortedBy { parseTask(it).from.ifEmpty { "99:99" }.padStart(5, '0') }
                        items.clear()
                        items.addAll(sorted)
                        save()
                        newTitle = ""; tFrom = ""; tTo = ""
                    }
                }) { Text(tr("افزودن", "Add")) }
            }
        }
        Gap(10)
        // اسکجولر هفتگی (مثل Class Schedule)
        val sg = jalaliToGregorian(jy, jm, selected)
        val sel = LocalDate.of(sg.first, sg.second, sg.third)
        val weekStart = sel.minusDays(weekdayIndex(sel).toLong())
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("اسکجول هفته", "Weekly Schedule"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Gap(8)
            for (i in 0 until 7) {
                val dt = weekStart.plusDays(i.toLong())
                val dj = gregorianToJalali(dt.year, dt.monthValue, dt.dayOfMonth)
                val list = if (ver >= 0) NavaStore.getChecklist("${dj.first}-${dj.second}-${dj.third}").map { parseTask(it) } else emptyList()
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                    Column(Modifier.width(54.dp)) {
                        Text(weekdayNames[i].take(if (Lang.fa) 3 else 3), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(fa(dj.third), fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxHeight()) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(if (dt == today) pal[4] else MaterialTheme.colorScheme.onBackground))
                        Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(
                        Modifier.weight(1f).padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.18f)).padding(10.dp)
                    ) {
                        if (list.isEmpty()) Text("—", fontSize = 12.sp)
                        for (t in list) {
                            Row {
                                Text(
                                    if (t.from.isNotEmpty()) fa("${t.from}-${t.to}") else "",
                                    fontSize = 11.sp, modifier = Modifier.width(86.dp)
                                )
                                Text(t.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
