package com.mrahmadiaan.nava

import android.app.Application
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.mrahmadiaan.nava.ui.PaletteState
import org.osmdroid.config.Configuration

data class MsgItem(
    val pkg: String,
    val appName: String,
    val sender: String,
    val text: String,
    val intent: PendingIntent?,
    val reply: Notification.Action?
)

data class GeoEvent(val kind: String, val title: String, val lat: Double, val lon: Double)

object NavaStore {
    private var prefs: SharedPreferences? = null
    val messages = mutableStateListOf<MsgItem>()
    val trackPoints = mutableStateListOf<Pair<Double, Double>>()
    val events = mutableStateListOf<GeoEvent>()
    val allowed = mutableStateListOf<String>()
    var lastLat by mutableStateOf<Double?>(null)
    var lastLon by mutableStateOf<Double?>(null)
    var tracking by mutableStateOf(false)

    fun sp(): SharedPreferences = prefs!!

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("nava", Context.MODE_PRIVATE)
        prefs = p
        val saved = p.getStringSet("allowed", null)
            ?: setOf("com.whatsapp", "org.telegram.messenger", "com.instagram.android")
        allowed.clear()
        allowed.addAll(saved)
        val pal = p.getString("palette", null)
        if (pal != null) {
            val l = pal.split(",").mapNotNull { it.toIntOrNull() }
            if (l.size == 5) PaletteState.colors = l.map { Color(it) }
        }
    }

    fun savePalette(c: List<Color>) {
        sp().edit().putString("palette", c.joinToString(",") { it.toArgb().toString() }).apply()
    }

    fun resetPalette() {
        sp().edit().remove("palette").apply()
        PaletteState.colors = PaletteState.default
    }

    private fun saveAllowed() {
        sp().edit().putStringSet("allowed", allowed.toSet()).apply()
    }

    fun addAllowed(pkg: String) {
        if (!allowed.contains(pkg)) {
            allowed.add(pkg)
            saveAllowed()
        }
    }

    fun removeAllowed(pkg: String) {
        allowed.remove(pkg)
        saveAllowed()
    }

    fun addMessage(m: MsgItem) {
        messages.add(0, m)
        if (messages.size > 100) messages.removeAt(messages.size - 1)
    }

    fun addPoint(lat: Double, lon: Double) {
        lastLat = lat
        lastLon = lon
        trackPoints.add(lat to lon)
        if (trackPoints.size > 5000) trackPoints.removeAt(0)
    }

    fun addEventHere(kind: String, title: String) {
        val la = lastLat
        val lo = lastLon
        if (la != null && lo != null) {
            events.add(GeoEvent(kind, title, la, lo))
            if (events.size > 200) events.removeAt(0)
        }
    }

    fun getChecklist(key: String): List<String> {
        val s = sp().getString("chk_$key", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun setChecklist(key: String, items: List<String>) {
        sp().edit().putString("chk_$key", items.joinToString("\n")).apply()
    }
}

class NavaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NavaStore.init(this)
        val cfg = Configuration.getInstance()
        cfg.load(this, getSharedPreferences("osm", Context.MODE_PRIVATE))
        cfg.userAgentValue = packageName
    }
}
