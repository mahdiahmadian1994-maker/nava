package com.mrahmadiaan.nava.ui

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.LockScreenActivity
import com.mrahmadiaan.nava.NavaAdmin
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val P_BG = Color(0xFF463A6E)
private val P_PANEL = Color(0xFF3A2F5E)
private val P_DARK = Color(0xFF2E2450)
private val P_PEACH = Color(0xFFF2C28B)
private val P_PINK = Color(0xFFEF9A9A)
private val P_BLUE = Color(0xFF8EC5F5)
private val P_LILAC = Color(0xFFB38DF0)
private val P_CREAM = Color(0xFFF3EDE2)

fun lockNow(ctx: Context) {
    val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val comp = ComponentName(ctx, NavaAdmin::class.java)
    if (dpm.isAdminActive(comp)) {
        dpm.lockNow()
    } else {
        ctx.startActivity(Intent(ctx, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun DotSlider(value: Float, onChange: (Float) -> Unit, fill: Color, modifier: Modifier = Modifier) {
    var w by remember { mutableStateOf(1f) }
    Canvas(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { onChange((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    onChange((change.position.x / w).coerceIn(0f, 1f))
                }
            }
    ) {
        val h = size.height
        val top = h * 0.3f
        drawRoundRect(P_DARK, Offset(0f, top), Size(size.width, h * 0.4f), CornerRadius(h * 0.2f))
        val tx = (size.width * value).coerceIn(h * 0.5f, size.width - h * 0.5f)
        drawRoundRect(fill, Offset(0f, top), Size(tx, h * 0.4f), CornerRadius(h * 0.2f))
        for (i in 1..7) drawCircle(Color.White.copy(alpha = 0.5f), 2.5f, Offset(size.width * i / 8f, h / 2))
        drawCircle(Color.White, h * 0.5f, Offset(tx, h / 2))
        drawCircle(P_PEACH, h * 0.42f, Offset(tx, h / 2))
    }
}

@Composable
private fun VolumeRow(icon: String, stream: Int, fill: Color) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val max = remember { am.getStreamMaxVolume(stream).coerceAtLeast(1) }
    var v by remember { mutableStateOf(am.getStreamVolume(stream).toFloat() / max) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Ico(icon, P_PEACH, 20.dp)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            DotSlider(v, {
                v = it
                try { am.setStreamVolume(stream, (it * max).roundToInt(), 0) } catch (e: Exception) { }
            }, fill)
        }
        Text("  " + fa((v * 100).roundToInt()), color = P_CREAM, fontSize = 12.sp)
    }
}

@Composable
private fun RoundBtn(icon: String, bg: Color, on: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(if (on) P_PEACH else bg).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Ico(icon, P_DARK, 22.dp) }
}

@Composable
fun QuickAccessBar(nav: NavController) {
    val ctx = LocalContext.current
    var torch by remember { mutableStateOf(false) }
    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30000)
            battery = batteryPercent(ctx)
        }
    }
    fun setTorch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id != null) {
                cm.setTorchMode(id, on)
                torch = on
            }
        } catch (e: Exception) {
        }
    }
    fun open(i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    val routes = listOf(
        Triple("tracking", "map", tr("ترکینگ", "Track")),
        Triple("calendar", "calendar", tr("تقویم", "Calendar")),
        Triple("messages", "chat", tr("پیام", "Messages")),
        Triple("health", "heart", tr("سلامت", "Health")),
        Triple("weather", "cloud", tr("هوا", "Weather")),
        Triple("markets", "chart", tr("بازار", "Markets")),
        Triple("music", "music", tr("موزیک", "Music")),
        Triple("usage", "pie", tr("آمار", "Usage")),
        Triple("assistant", "bot", tr("دستیار", "Assistant")),
        Triple("settings", "gear", tr("تنظیمات", "Settings"))
    )
    val tints = listOf(P_BLUE, P_PINK, P_LILAC, P_PEACH)

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(P_BG).padding(14.dp)) {
        Text("Nava", color = P_CREAM, fontSize = 15.sp, fontWeight = FontWeight.Light)
        Text(tr("دسترسی سریع", "Quick Access"), color = P_CREAM, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Gap(10)
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(P_PEACH).padding(14.dp)) {
            Column(Modifier.weight(1f)) {
                Text(tr("باتری", "Battery"), color = P_DARK, fontSize = 12.sp)
                Text(if (battery >= 0) fa(battery) + "%" else "—", color = P_DARK, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Gap(8)
                Box(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(P_BG)
                        .clickable { lockNow(ctx) }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                ) { Text(tr("قفل صفحه", "Lock now"), color = P_CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
            Column(
                Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White).padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                RoundBtn("lock", P_LILAC) { lockNow(ctx) }
                RoundBtn("flash", P_BLUE, torch) { setTorch(!torch) }
                RoundBtn("wifi", P_PINK) {
                    if (Build.VERSION.SDK_INT >= 29) open(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                    else open(Intent(Settings.ACTION_WIFI_SETTINGS))
                }
                RoundBtn("bt", P_BLUE) { open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            }
        }
        Gap(10)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(P_PANEL).padding(14.dp)) {
            VolumeRow("music", AudioManager.STREAM_MUSIC, P_BLUE)
            Gap(6)
            VolumeRow("alarm", AudioManager.STREAM_ALARM, P_LILAC)
        }
        Gap(10)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            for ((i, r) in routes.withIndex()) {
                Column(
                    Modifier.padding(end = 8.dp).width(66.dp).clip(RoundedCornerShape(33.dp)).background(P_PANEL)
                        .clickable { nav.navigate(r.first) }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(tints[i % 4]), contentAlignment = Alignment.Center) {
                        Ico(r.second, P_DARK, 22.dp)
                    }
                    Text(r.third, color = P_CREAM, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                    Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(P_PEACH))
                }
            }
        }
    }
}
