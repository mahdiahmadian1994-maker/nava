package com.mrahmadiaan.nava.ui

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.LockScreenActivity
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.abs

// این مقدار در زمان بیلد خودکار با نام کاربری/مخزن گیت‌هاب شما جایگزین می‌شود
const val UPDATE_URL = "https://raw.githubusercontent.com/OWNER_REPO/main/version.json"
const val APP_VERSION_CODE = 1

fun extractPalette(src: Bitmap): List<Color> {
    val small = Bitmap.createScaledBitmap(src, 48, 48, true)
    val counts = HashMap<Int, Int>()
    for (x in 0 until 48) {
        for (y in 0 until 48) {
            val p = small.getPixel(x, y)
            val r = android.graphics.Color.red(p) shr 5
            val g = android.graphics.Color.green(p) shr 5
            val b = android.graphics.Color.blue(p) shr 5
            val k = (r shl 6) or (g shl 3) or b
            counts[k] = (counts[k] ?: 0) + 1
        }
    }
    val picked = mutableListOf<IntArray>()
    for (e in counts.entries.sortedByDescending { it.value }) {
        val r = ((e.key shr 6) and 7) * 32 + 16
        val g = ((e.key shr 3) and 7) * 32 + 16
        val b = (e.key and 7) * 32 + 16
        val far = picked.all { abs(it[0] - r) + abs(it[1] - g) + abs(it[2] - b) > 90 }
        if (far) picked.add(intArrayOf(r, g, b))
        if (picked.size == 5) break
    }
    val out = picked.map { Color(it[0], it[1], it[2]) }.toMutableList()
    var i = 0
    while (out.size < 5) {
        out.add(PaletteState.default[i % 5])
        i++
    }
    return out
}

@Composable
fun SettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var updateMsg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val opts = BitmapFactory.Options()
                        opts.inSampleSize = 4
                        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    } catch (e: Exception) {
                        null
                    }
                }
                if (bmp != null) {
                    val pal = extractPalette(bmp)
                    PaletteState.colors = pal
                    NavaStore.savePalette(pal)
                    msg = "پالت جدید اعمال شد"
                } else {
                    msg = "خواندن عکس ممکن نشد"
                }
            }
        }
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    ScreenFrame("تنظیمات", nav) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("پالت رنگی", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in PaletteState.colors) Box(Modifier.size(36.dp).clip(CircleShape).background(c))
            }
            Gap(6)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch("image/*") }) { Text("انتخاب عکس") }
                OutlinedButton(onClick = { NavaStore.resetPalette(); msg = "پالت پیش‌فرض برگشت" }) { Text("ریست") }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
            Text("تم: خودکار مطابق سیستم (دارک/لایت)", fontSize = 12.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("بروزرسانی", fontWeight = FontWeight.Bold)
            Button(onClick = {
                updateMsg = "در حال بررسی..."
                scope.launch {
                    val t = httpGet(UPDATE_URL)
                    updateMsg = if (t == null) {
                        "ارتباط با سرور ممکن نشد"
                    } else {
                        try {
                            val j = JSONObject(t)
                            if (j.getInt("versionCode") > APP_VERSION_CODE) {
                                "نسخه جدید ${j.optString("versionName")} موجود است"
                            } else {
                                "شما آخرین نسخه را دارید"
                            }
                        } catch (e: Exception) {
                            "فایل version.json معتبر نیست"
                        }
                    }
                }
            }) { Text("بررسی آپدیت") }
            if (updateMsg.isNotEmpty()) Text(updateMsg, fontSize = 12.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("دسترسی‌ها", fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("دسترسی نوتیفیکیشن") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("دسترسی آمار استفاده") }
            OutlinedButton(onClick = {
                val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                locPerm.launch(perms.toTypedArray())
            }) { Text("دسترسی موقعیت مکانی") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("انتخاب به‌عنوان لانچر پیش‌فرض") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(ctx, LockScreenActivity::class.java))
            }) { Text("پیش‌نمایش صفحه قفل") }
        }
        Gap(16)
        Text("طراحی و توسعه: Mr.ahmadiaan · Nava Launcher v1.0.0", fontSize = 11.sp)
    }
}
