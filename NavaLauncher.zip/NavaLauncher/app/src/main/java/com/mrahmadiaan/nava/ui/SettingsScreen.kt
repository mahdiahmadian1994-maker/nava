package com.mrahmadiaan.nava.ui

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.core.content.ContextCompat
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.LockScreenActivity
import com.mrahmadiaan.nava.LockService
import com.mrahmadiaan.nava.NavaAdmin
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.abs

// این مقدار در زمان بیلد خودکار با نام کاربری/مخزن گیت‌هاب شما جایگزین می‌شود
const val UPDATE_URL = "https://raw.githubusercontent.com/OWNER_REPO/main/version.json"
const val APP_VERSION_CODE = 3

fun extractPalette(src: Bitmap): List<Color> {
    val small = Bitmap.createScaledBitmap(src, 48, 48, true)
    val counts = HashMap<Int, Int>()
    for (x in 0 until 48) {
        for (y in 0 until 48) {
            val p = small.getPixel(x, y)
            val r = android.graphics.Color.red(p) shr 5
            val g = android.graphics.Color.green(p) shr 5
            val b = android.graphics.Color.blue(p) shr 5
            val k = (r shl 6) or (g shl 3) or b
            counts[k] = (counts[k] ?: 0) + 1
        }
    }
    val picked = mutableListOf<IntArray>()
    for (e in counts.entries.sortedByDescending { it.value }) {
        val r = ((e.key shr 6) and 7) * 32 + 16
        val g = ((e.key shr 3) and 7) * 32 + 16
        val b = (e.key and 7) * 32 + 16
        val far = picked.all { abs(it[0] - r) + abs(it[1] - g) + abs(it[2] - b) > 90 }
        if (far) picked.add(intArrayOf(r, g, b))
        if (picked.size == 5) break
    }
    val out = picked.map { Color(it[0], it[1], it[2]) }.toMutableList()
    var i = 0
    while (out.size < 5) {
        out.add(PaletteState.default[i % 5])
        i++
    }
    return out
}

@Composable
fun SettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var updateMsg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    try {
                        val opts = BitmapFactory.Options()
                        opts.inSampleSize = 4
                        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    } catch (e: Exception) {
                        null
                    }
                }
                if (bmp != null) {
                    val pal = extractPalette(bmp)
                    PaletteState.colors = pal
                    NavaStore.savePalette(pal)
                    msg = tr("پالت جدید اعمال شد", "New palette applied")
                } else {
                    msg = tr("خواندن عکس ممکن نشد", "Could not read image")
                }
            }
        }
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    ScreenFrame(tr("تنظیمات", "Settings"), nav) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("زبان", "Language"), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (Lang.fa) {
                    Button(onClick = { NavaStore.setLang(true) }) { Text("فارسی") }
                    OutlinedButton(onClick = { NavaStore.setLang(false) }) { Text("English") }
                } else {
                    OutlinedButton(onClick = { NavaStore.setLang(true) }) { Text("فارسی") }
                    Button(onClick = { NavaStore.setLang(false) }) { Text("English") }
                }
            }
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("پالت رنگی", "Color palette"), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in PaletteState.colors) Box(Modifier.size(36.dp).clip(CircleShape).background(c))
            }
            Gap(6)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch("image/*") }) { Text(tr("انتخاب عکس", "Pick image")) }
                OutlinedButton(onClick = {
                    NavaStore.resetPalette()
                    msg = tr("پالت پیش‌فرض برگشت", "Palette reset")
                }) { Text(tr("ریست", "Reset")) }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
            Text(tr("تم: خودکار مطابق سیستم (دارک/لایت)", "Theme: follows system (dark/light)"), fontSize = 12.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("بروزرسانی", "Update"), fontWeight = FontWeight.Bold)
            Button(onClick = {
                updateMsg = tr("در حال بررسی...", "Checking...")
                scope.launch {
                    val t = httpGet(UPDATE_URL)
                    updateMsg = if (t == null) {
                        tr("ارتباط با سرور ممکن نشد", "Could not reach server")
                    } else {
                        try {
                            val j = JSONObject(t)
                            if (j.getInt("versionCode") > APP_VERSION_CODE) {
                                tr("نسخه جدید موجود است: ", "New version available: ") + j.optString("versionName")
                            } else {
                                tr("شما آخرین نسخه را دارید", "You have the latest version")
                            }
                        } catch (e: Exception) {
                            tr("فایل version.json معتبر نیست", "version.json is invalid")
                        }
                    }
                }
            }) { Text(tr("بررسی آپدیت", "Check for update")) }
            if (updateMsg.isNotEmpty()) Text(updateMsg, fontSize = 12.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("قفل صفحه نوا", "Nava lock screen"), fontWeight = FontWeight.Bold)
            var customLock by remember { mutableStateOf(NavaStore.sp().getBoolean("customLock", false)) }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(tr("نمایش قفل نوا هنگام خاموش‌شدن صفحه", "Show Nava lock when screen turns off"), Modifier.weight(1f), fontSize = 13.sp)
                Switch(checked = customLock, onCheckedChange = { on ->
                    customLock = on
                    NavaStore.sp().edit().putBoolean("customLock", on).apply()
                    if (on) {
                        if (!Settings.canDrawOverlays(ctx)) {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        try { ContextCompat.startForegroundService(ctx, Intent(ctx, LockService::class.java)) } catch (e: Exception) { }
                    } else {
                        ctx.stopService(Intent(ctx, LockService::class.java))
                    }
                })
            }
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text(tr("اجازه نمایش روی بقیه اپ‌ها", "Allow display over other apps")) }
            OutlinedButton(onClick = {
                val comp = ComponentName(ctx, NavaAdmin::class.java)
                ctx.startActivity(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, tr("برای دکمه قفل صفحه", "For the lock button"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text(tr("فعال‌سازی دکمه قفل (Device Admin)", "Enable lock button (Device Admin)")) }
            Text(
                tr("قفل اصلی گوشی زیر قفل نوا می‌ماند؛ با لمس صفحه، رمز/اثرانگشت سیستم خواسته می‌شود.",
                    "The system lock stays underneath; tapping asks for your PIN/fingerprint."),
                fontSize = 11.sp
            )
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("دسترسی‌ها", "Permissions"), fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text(tr("دسترسی نوتیفیکیشن", "Notification access")) }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text(tr("دسترسی آمار استفاده", "Usage access")) }
            OutlinedButton(onClick = {
                val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                locPerm.launch(perms.toTypedArray())
            }) { Text(tr("دسترسی موقعیت مکانی", "Location access")) }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text(tr("انتخاب به‌عنوان لانچر پیش‌فرض", "Set as default launcher")) }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(ctx, LockScreenActivity::class.java))
            }) { Text(tr("پیش‌نمایش صفحه قفل", "Preview lock screen")) }
        }
        Gap(16)
        Text(tr("طراحی و توسعه: Mr.ahmadiaan · Nava Launcher v1.1.0", "Designed & developed by Mr.ahmadiaan · Nava Launcher v1.1.0"), fontSize = 11.sp)
    }
}
