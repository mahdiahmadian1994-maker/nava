package com.mrahmadiaan.nava.ui

import android.Manifest
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.random.Random

@Composable
fun HealthScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var steps by remember { mutableStateOf(0) }
    var permOk by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 29 || hasPerm(ctx, Manifest.permission.ACTIVITY_RECOGNITION))
    }
    var hr by remember { mutableStateOf(List(30) { 70f + Random.nextFloat() * 12f }) }
    val devices = remember { mutableStateListOf<Pair<String, String>>() }
    var status by remember { mutableStateOf("") }

    val stepPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permOk = it }
    val btPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    LaunchedEffect(Unit) {
        if (!permOk) stepPerm.launch(Manifest.permission.ACTIVITY_RECOGNITION)
    }
    LaunchedEffect(Unit) {
        while (true) {
            hr = hr.drop(1) + (70f + Random.nextFloat() * 12f)
            delay(1500)
        }
    }
    DisposableEffect(permOk) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val total = e.values[0]
                val key = "stepbase_${LocalDate.now()}"
                val sp = NavaStore.sp()
                if (!sp.contains(key)) sp.edit().putFloat(key, total).apply()
                steps = (total - sp.getFloat(key, total)).toInt().coerceAtLeast(0)
            }

            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null && permOk) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    val h = height.toFloatOrNull()
    val w = weight.toFloatOrNull()
    val bmi = if (h != null && w != null && h > 0f) w / ((h / 100f) * (h / 100f)) else null
    val bmiLabel = when {
        bmi == null -> "—"
        bmi < 18.5f -> "کم‌وزن"
        bmi < 25f -> "نرمال"
        bmi < 30f -> "اضافه‌وزن"
        else -> "چاقی"
    }

    ScreenFrame("سلامت", nav) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("شاخص توده بدنی (BMI)", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = height, onValueChange = { height = it }, singleLine = true,
                    label = { Text("قد (cm)") }, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = weight, onValueChange = { weight = it }, singleLine = true,
                    label = { Text("وزن (kg)") }, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
            Text(
                if (bmi != null) "BMI: ${fa("%.1f".format(bmi))} · $bmiLabel" else "قد و وزن را وارد کنید",
                fontSize = 18.sp
            )
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                PulseRing(steps / 8000f, Pal.green, fa(steps))
                PulseRing((steps * 0.04f) / 400f, Pal.orange, fa((steps * 0.04f).toInt()) + " kcal")
            }
            Text("قدم‌ها (هدف ۸۰۰۰) · کالری تخمینی", fontSize = 12.sp)
            if (!permOk) Text("دسترسی فعالیت بدنی داده نشده است.", fontSize = 12.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("ضربان قلب: ${fa(hr.last().toInt())} bpm", fontWeight = FontWeight.Bold)
            PulseLine(hr, Pal.terracotta)
            Text("نمونه نمایشی؛ بعد از اتصال ساعت، داده واقعی جایگزین می‌شود.", fontSize = 11.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("ساعت هوشمند بلوتوثی", fontWeight = FontWeight.Bold)
            Button(onClick = {
                val perms = if (Build.VERSION.SDK_INT >= 31) {
                    arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                btPerm.launch(perms)
                try {
                    val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                    val scanner = bm.adapter?.bluetoothLeScanner
                    if (scanner == null) {
                        status = "بلوتوث خاموش یا در دسترس نیست"
                    } else {
                        devices.clear()
                        status = "در حال جستجو..."
                        val cb = object : ScanCallback() {
                            override fun onScanResult(callbackType: Int, result: ScanResult) {
                                val d = result.device
                                val rawName: String? = try { d.name } catch (e: SecurityException) { null }
                                val name = rawName ?: "ناشناس"
                                if (devices.none { it.first == d.address } && devices.size < 12) {
                                    devices.add(d.address to name)
                                }
                            }
                        }
                        scanner.startScan(cb)
                        scope.launch {
                            delay(8000)
                            try { scanner.stopScan(cb) } catch (e: Exception) { }
                            status = "جستجو تمام شد"
                        }
                    }
                } catch (e: SecurityException) {
                    status = "دسترسی بلوتوث لازم است؛ دوباره امتحان کنید"
                }
            }) { Text("جستجوی دستگاه") }
            if (status.isNotEmpty()) Text(status, fontSize = 12.sp)
            for (d in devices.toList()) {
                TextButton(onClick = {
                    try {
                        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                        bm.adapter.getRemoteDevice(d.first).connectGatt(ctx, false, object : BluetoothGattCallback() {
                            override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
                                if (newState == BluetoothProfile.STATE_CONNECTED) {
                                    status = "متصل شد: ${d.second}"
                                    try { g.discoverServices() } catch (e: SecurityException) { }
                                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                                    status = "قطع شد: ${d.second}"
                                }
                            }
                        })
                        status = "در حال اتصال به ${d.second}..."
                    } catch (e: Exception) {
                        status = "اتصال ممکن نشد"
                    }
                }) { Text("${d.second} (${d.first})", fontSize = 12.sp) }
            }
        }
    }
}
