package com.mrahmadiaan.nava.ui

import android.Manifest
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.random.Random

@Composable
private fun StatRow(icon: String, value: String, goal: String, label: String, tint: androidx.compose.ui.graphics.Color) {
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ico(icon, tint, 22.dp)
            Column(Modifier.padding(horizontal = 10.dp)) {
                Text(label, fontSize = 11.sp)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = tint)
                    Text(" / $goal", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun HealthScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pal = PaletteState.colors
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var steps by remember { mutableStateOf(0) }
    var permOk by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 29 || hasPerm(ctx, Manifest.permission.ACTIVITY_RECOGNITION))
    }
    var hr by remember { mutableStateOf(List(40) { 70f + Random.nextFloat() * 14f }) }
    val devices = remember { mutableStateListOf<Pair<String, String>>() }
    var status by remember { mutableStateOf("") }

    val stepPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permOk = it }
    val btPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    LaunchedEffect(Unit) { if (!permOk) stepPerm.launch(Manifest.permission.ACTIVITY_RECOGNITION) }
    LaunchedEffect(Unit) {
        while (true) {
            hr = hr.drop(1) + (70f + Random.nextFloat() * 14f)
            delay(1500)
        }
    }
    DisposableEffect(permOk) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val total = e.values[0]
                val sp = NavaStore.sp()
                val key = "stepbase_${LocalDate.now()}"
                if (!sp.contains(key)) sp.edit().putFloat(key, total).apply()
                steps = (total - sp.getFloat(key, total)).toInt().coerceAtLeast(0)
                sp.edit().putInt("stepsday_${LocalDate.now()}", steps).apply()
            }

            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null && permOk) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    val cal = (steps * 0.04f).toInt()
    val activeMin = steps / 110
    val score = (((steps / 8000f).coerceAtMost(1f) + (cal / 400f).coerceAtMost(1f)) / 2f * 1000f).toInt()
    val h = height.toFloatOrNull()
    val w = weight.toFloatOrNull()
    val bmi = if (h != null && w != null && h > 0f) w / ((h / 100f) * (h / 100f)) else null
    val bmiLabel = when {
        bmi == null -> "—"
        bmi < 18.5f -> tr("کم‌وزن", "Underweight")
        bmi < 25f -> tr("نرمال", "Normal")
        bmi < 30f -> tr("اضافه‌وزن", "Overweight")
        else -> tr("چاقی", "Obese")
    }

    ScreenFrame(tr("سلامت", "Health"), nav) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassCard(Modifier.weight(1.15f)) {
                Text(tr("فعالیت روزانه", "Daily Activity"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                PulseRing(
                    steps / 8000f, pal[4], fa(score), Modifier.size(150.dp),
                    progress2 = cal / 400f, color2 = pal[2], sub = tr("از ۱۰۰۰", "of 1000")
                )
                if (!permOk) Text(tr("دسترسی فعالیت بدنی لازم است", "Activity permission needed"), fontSize = 10.sp)
            }
            Column(Modifier.weight(1f)) {
                StatRow("heart", fa(cal), "400", tr("کالری", "Calories"), pal[2])
                StatRow("map", fa(steps), "8000", tr("قدم", "Steps"), pal[4])
                StatRow("clock", fa(activeMin), "60", tr("دقیقه فعال", "Active min"), pal[1])
            }
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ico("heart", pal[2], 20.dp)
                Text("  " + tr("ضربان قلب", "Heart Rate"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(tr("نمونه", "DEMO"), fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(fa(hr.last().toInt()), fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text(" BPM", fontSize = 12.sp)
            }
            PulseLine(hr, pal[2], Modifier.fillMaxWidth().height(90.dp))
            Text(tr("داده نمایشی؛ بعد از اتصال ساعت واقعی می‌شود.", "Demo data until a watch is connected."), fontSize = 10.sp)
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("قدم‌های هفته", "Weekly Steps"), fontWeight = FontWeight.Bold)
            Gap(6)
            val sp = NavaStore.sp()
            val days = (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }
            val vals = days.map { d -> if (d == LocalDate.now()) steps else sp.getInt("stepsday_$d", 0) }
            val mx = (vals.maxOrNull() ?: 1).coerceAtLeast(1000)
            val barColor = pal[3].let { if (it.red < 0.3f && it.green < 0.4f) pal[0] else it }
            Canvas(Modifier.fillMaxWidth().height(100.dp)) {
                val bw = size.width / 14f
                for (i in vals.indices) {
                    val hh = size.height * (vals[i].toFloat() / mx).coerceAtLeast(0.04f)
                    val x = size.width * (i + 0.5f) / 7f - bw / 2
                    drawRoundRect(
                        if (i == 6) pal[4] else barColor,
                        Offset(x, size.height - hh), Size(bw, hh), CornerRadius(bw / 2, bw / 2)
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                for (d in days) Text(weekdayNames[(d.dayOfWeek.value + 1) % 7].take(1), fontSize = 10.sp)
            }
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text("BMI", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = height, onValueChange = { height = it }, singleLine = true,
                    label = { Text(tr("قد (cm)", "Height (cm)")) }, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = weight, onValueChange = { weight = it }, singleLine = true,
                    label = { Text(tr("وزن (kg)", "Weight (kg)")) }, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
            Text(
                if (bmi != null) "BMI ${fa("%.1f".format(bmi))} · $bmiLabel" else tr("قد و وزن را وارد کنید", "Enter height and weight"),
                fontSize = 18.sp
            )
        }
        Gap(10)
        GlassCard(Modifier.fillMaxWidth()) {
            Text(tr("ساعت هوشمند بلوتوثی", "Bluetooth Smartwatch"), fontWeight = FontWeight.Bold)
            Button(onClick = {
                val perms = if (Build.VERSION.SDK_INT >= 31) {
                    arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                }
                btPerm.launch(perms)
                try {
                    val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                    val scanner = bm.adapter?.bluetoothLeScanner
                    if (scanner == null) {
                        status = tr("بلوتوث خاموش است", "Bluetooth is off")
                    } else {
                        devices.clear()
                        status = tr("در حال جستجو...", "Scanning...")
                        val cb = object : ScanCallback() {
                            override fun onScanResult(callbackType: Int, result: ScanResult) {
                                val d = result.device
                                val rawName: String? = try { d.name } catch (e: SecurityException) { null }
                                val name = rawName ?: "?"
                                if (devices.none { it.first == d.address } && devices.size < 12) {
                                    devices.add(d.address to name)
                                }
                            }
                        }
                        scanner.startScan(cb)
                        scope.launch {
                            delay(8000)
                            try { scanner.stopScan(cb) } catch (e: Exception) { }
                            status = tr("جستجو تمام شد", "Scan finished")
                        }
                    }
                } catch (e: SecurityException) {
                    status = tr("دسترسی بلوتوث لازم است؛ دوباره امتحان کنید", "Bluetooth permission needed; try again")
                }
            }) { Text(tr("جستجوی دستگاه", "Scan devices")) }
            if (status.isNotEmpty()) Text(status, fontSize = 12.sp)
            for (d in devices.toList()) {
                TextButton(onClick = {
                    try {
                        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                        bm.adapter.getRemoteDevice(d.first).connectGatt(ctx, false, object : BluetoothGattCallback() {
                            override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
                                if (newState == BluetoothProfile.STATE_CONNECTED) {
                                    status = tr("متصل شد: ", "Connected: ") + d.second
                                    try { g.discoverServices() } catch (e: SecurityException) { }
                                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                                    status = tr("قطع شد: ", "Disconnected: ") + d.second
                                }
                            }
                        })
                        status = tr("در حال اتصال...", "Connecting...")
                    } catch (e: Exception) {
                        status = tr("اتصال ممکن نشد", "Could not connect")
                    }
                }) { Text("${d.second} (${d.first})", fontSize = 12.sp) }
            }
        }
    }
}
