package com.mrahmadiaan.nava.ui

import android.content.Intent
import android.net.TrafficStats
import android.provider.Settings
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

private data class UsageRow(val label: String, val ms: Long)

private fun fmt(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) "${fa(m / 60)} ساعت و ${fa(m % 60)} دقیقه" else "${fa(m)} دقیقه"
}

@Composable
fun UsageScreen(nav: NavController) {
    val ctx = LocalContext.current
    var has by remember { mutableStateOf(hasUsageAccess(ctx)) }
    var rows by remember { mutableStateOf<List<UsageRow>>(emptyList()) }
    var total by remember { mutableStateOf(1L) }
    var refresh by remember { mutableStateOf(0) }

    LaunchedEffect(has, refresh) {
        has = hasUsageAccess(ctx)
        if (has) {
            val result = withContext(Dispatchers.Default) {
                val pm = ctx.packageManager
                val map = try { usageToday(ctx) } catch (e: Exception) { emptyMap() }
                map.entries.map { en ->
                    val label = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(en.key, 0)).toString()
                    } catch (e: Exception) {
                        en.key
                    }
                    UsageRow(label, en.value)
                }.sortedByDescending { it.ms }
            }
            total = result.sumOf { it.ms }.coerceAtLeast(1L)
            rows = result.take(15)
        }
    }

    val net = remember(refresh) {
        val t = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
        val key = "netbase_${LocalDate.now()}"
        val sp = NavaStore.sp()
        if (!sp.contains(key) || sp.getLong(key, 0L) > t) sp.edit().putLong(key, t).apply()
        (t - sp.getLong(key, t)).coerceAtLeast(0L)
    }

    ScreenFrame("آمار استفاده", nav) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("مصرف اینترنت امروز", fontWeight = FontWeight.Bold)
            Text("${fa("%.1f".format(net / 1048576.0))} مگابایت", fontSize = 24.sp)
            Text("از اولین باز شدن اپ امروز محاسبه می‌شود", fontSize = 11.sp)
        }
        Gap(10)
        if (!has) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("برای نمایش زمان استفاده، دسترسی Usage Access را فعال کنید.")
                Button(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("فعال‌سازی") }
                TextButton(onClick = { refresh++ }) { Text("بررسی دوباره") }
            }
        } else {
            TextButton(onClick = { refresh++ }) { Text("بروزرسانی") }
            if (rows.isEmpty()) Text("هنوز داده‌ای ثبت نشده است.")
            val pal = PaletteState.colors
            rows.forEachIndexed { i, r ->
                val frac = r.ms.toFloat() / total.toFloat()
                Text("${r.label} · ${fmt(r.ms)} · ${fa((frac * 100).toInt())}٪", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                LinearProgressIndicator(
                    progress = frac,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    color = pal[i % pal.size]
                )
            }
        }
    }
}
