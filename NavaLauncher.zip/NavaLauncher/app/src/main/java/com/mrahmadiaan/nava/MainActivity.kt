package com.mrahmadiaan.nava

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mrahmadiaan.nava.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (NavaStore.sp().getBoolean("customLock", false) && Settings.canDrawOverlays(this)) {
            try { ContextCompat.startForegroundService(this, Intent(this, LockService::class.java)) } catch (e: Exception) { }
        }
        setContent {
            NavaTheme {
                ParticleLayer {
                    val nav = rememberNavController()
                    NavHost(
                        navController = nav,
                        startDestination = "home",
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable("home") { HomeScreen(nav) }
                        composable("tracking") { TrackingScreen(nav) }
                        composable("calendar") { CalendarScreen(nav) }
                        composable("messages") { MessagesScreen(nav) }
                        composable("health") { HealthScreen(nav) }
                        composable("weather") { WeatherScreen(nav) }
                        composable("markets") { MarketsScreen(nav) }
                        composable("music") { MusicPlayerScreen(nav) }
                        composable("usage") { UsageScreen(nav) }
                        composable("assistant") { AssistantScreen(nav) }
                        composable("settings") { SettingsScreen(nav) }
                    }
                }
            }
        }
    }
}
