package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlin.math.sin

// برای فعال‌سازی نمودار این سه مورد، کلید API سرویس دلخواه را اینجا بگذارید
const val API_KEY_GOLD = ""
const val API_KEY_OIL = ""
const val API_KEY_FX = ""

private fun demoSeries(seed: Float): List<Float> = List(24) { i -> 50f + 10f * sin(i / 3f + seed) }

@Composable
fun MarketsScreen(nav: NavController) {
    var btc by remember { mutableStateOf<List<Float>>(emptyList()) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val t = httpGet("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1")
        if (t == null) {
            failed = true
        } else {
            try {
                val arr = JSONObject(t).getJSONArray("prices")
                val out = mutableListOf<Float>()
                var i = 0
                while (i < arr.length()) {
                    out.add(arr.getJSONArray(i).getDouble(1).toFloat())
                    i += 6
                }
                btc = out
            } catch (e: Exception) {
                failed = true
            }
        }
    }

    val pal = PaletteState.colors
    val btcText = when {
        btc.isNotEmpty() -> "$" + fa(btc.last().roundToInt())
        failed -> "خطا در دریافت"
        else -> "در حال دریافت..."
    }
    val cards = listOf(
        Triple("XAU/USD · طلا", if (API_KEY_GOLD.isEmpty()) "نیاز به کلید API" else "—", demoSeries(0f)),
        Triple("BTC/USD · بیت‌کوین", btcText, if (btc.size > 1) btc else demoSeries(1f)),
        Triple("نفت برنت", if (API_KEY_OIL.isEmpty()) "نیاز به کلید API" else "—", demoSeries(2f)),
        Triple("USD/CNY", if (API_KEY_FX.isEmpty()) "نیاز به کلید API" else "—", demoSeries(3f))
    )

    ScreenFrame("بازارها", nav) {
        cards.forEachIndexed { i, c ->
            val col = pal[i % pal.size]
            GlassCard(Modifier.fillMaxWidth()) {
                Text(c.first, fontWeight = FontWeight.Bold, color = col)
                Text(c.second, fontSize = 24.sp)
                PulseLine(c.third, col)
            }
            Gap(10)
        }
        Text("BTC از CoinGecko · بقیه نمونه نمایشی تا قرار دادن کلید API", fontSize = 11.sp)
    }
}
