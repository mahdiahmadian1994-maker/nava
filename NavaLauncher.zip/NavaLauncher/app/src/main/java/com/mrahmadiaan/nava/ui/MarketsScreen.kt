package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// برای فعال‌سازی این سه مورد، کلید API سرویس دلخواه را اینجا بگذارید
const val API_KEY_GOLD = ""
const val API_KEY_OIL = ""
const val API_KEY_FX = ""

private fun demoSeries(seed: Float): List<Float> = List(24) { i -> 50f + 10f * sin(i / 3f + seed) }

/** شکل نامتقارن (بلاب) با منحنی صاف */
private fun blobPath(w: Float, h: Float, seed: Int): Path {
    val n = 8
    val pts = List(n) { k ->
        val a = k * 2.0 * PI / n
        val r = 0.72f + 0.28f * (0.5f + 0.5f * sin(seed * 2.3 + k * 1.9).toFloat())
        Offset(w / 2f + cos(a).toFloat() * w / 2f * r, h / 2f + sin(a).toFloat() * h / 2f * r)
    }
    val path = Path()
    path.moveTo(pts[0].x, pts[0].y)
    for (i in 0 until n) {
        val p0 = pts[(i - 1 + n) % n]
        val p1 = pts[i]
        val p2 = pts[(i + 1) % n]
        val p3 = pts[(i + 2) % n]
        path.cubicTo(
            p1.x + (p2.x - p0.x) / 6f, p1.y + (p2.y - p0.y) / 6f,
            p2.x - (p3.x - p1.x) / 6f, p2.y - (p3.y - p1.y) / 6f,
            p2.x, p2.y
        )
    }
    path.close()
    return path
}

@Composable
private fun BlobCard(
    name: String, price: String, series: List<Float>,
    c1: Color, c2: Color, seed: Int, modifier: Modifier
) {
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            // لایه پشتی کمرنگ (مثل نمونه)
            val back = blobPath(size.width * 0.92f, size.height * 0.92f, seed + 3)
            clipPath(back) { }
            drawPath(back, c1.copy(alpha = 0.30f))
            val main = blobPath(size.width * 0.9f, size.height * 0.9f, seed)
            drawPath(main, Brush.linearGradient(listOf(c1, c2), Offset.Zero, Offset(size.width, size.height)))
            clipPath(main) {
                var y = size.height * 0.08f
                while (y < size.height * 0.45f) {
                    var x = size.width * 0.5f
                    while (x < size.width * 0.9f) {
                        drawCircle(Color.White.copy(alpha = 0.35f), 2.2f, Offset(x, y))
                        x += 14f
                    }
                    y += 14f
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(26.dp)) {
            Text(name, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center)
            Text(price, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            PulseLine(series, Color.White, Modifier.fillMaxWidth().height(34.dp))
        }
    }
}

@Composable
fun MarketsScreen(nav: NavController) {
    var btc by remember { mutableStateOf<List<Float>>(emptyList()) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val t = httpGet("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1")
        if (t == null) {
            failed = true
        } else {
            try {
                val arr = JSONObject(t).getJSONArray("prices")
                val out = mutableListOf<Float>()
                var i = 0
                while (i < arr.length()) {
                    out.add(arr.getJSONArray(i).getDouble(1).toFloat())
                    i += 6
                }
                btc = out
            } catch (e: Exception) {
                failed = true
            }
        }
    }

    val needKey = tr("نیاز به کلید API", "API key needed")
    val btcText = when {
        btc.isNotEmpty() -> "$" + fa(btc.last().roundToInt())
        failed -> tr("خطا", "Error")
        else -> "..."
    }

    ScreenFrame(tr("بازارها", "Markets"), nav) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            BlobCard(
                "XAU/USD", if (API_KEY_GOLD.isEmpty()) needKey else "—", demoSeries(0f),
                Color(0xFFE8336D), Color(0xFFB5258F), 1, Modifier.weight(1f)
            )
            BlobCard(
                "BTC/USD", btcText, if (btc.size > 1) btc else demoSeries(1f),
                Color(0xFFF05A1A), Color(0xFFF58A2B), 4, Modifier.weight(1f)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            BlobCard(
                tr("نفت برنت", "Brent Oil"), if (API_KEY_OIL.isEmpty()) needKey else "—", demoSeries(2f),
                Color(0xFFFF8A1F), Color(0xFFFFB04A), 7, Modifier.weight(1f)
            )
            BlobCard(
                "USD/CNY", if (API_KEY_FX.isEmpty()) needKey else "—", demoSeries(3f),
                Color(0xFF7B1C6E), Color(0xFF4E0E4F), 10, Modifier.weight(1f)
            )
        }
        Gap(8)
        Text(tr("BTC از CoinGecko · بقیه نمونه تا قرار دادن کلید API", "BTC from CoinGecko · others are demo until an API key is set"), fontSize = 11.sp)
    }
}
