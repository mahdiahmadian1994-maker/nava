package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import kotlin.math.roundToInt

@Composable
fun DashPanel(
    title: String, icon: String, tint: Color, modifier: Modifier, onOpen: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassCard(modifier, onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ico(icon, tint, 18.dp)
            Text(title, Modifier.weight(1f).padding(horizontal = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.2f)))
        content()
    }
}

@Composable
private fun MiniRing(progress: Float, label: String, caption: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxWidth().height(62.dp).padding(4.dp)) {
                drawArc(color.copy(alpha = 0.25f), 0f, 360f, false, style = Stroke(width = 5f, cap = StrokeCap.Round))
                drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, style = Stroke(width = 5f, cap = StrokeCap.Round))
            }
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text(caption, fontSize = 10.sp)
    }
}

private fun todayKey(): String {
    val t = LocalDate.now()
    val j = gregorianToJalali(t.year, t.monthValue, t.dayOfMonth)
    return "${j.first}-${j.second}-${j.third}"
}

private class DTask(val done: Boolean, val from: String, val title: String)

private fun todayTasks(): List<DTask> = NavaStore.getChecklist(todayKey()).map {
    val p = it.split("|", limit = 4)
    if (p.size == 4) DTask(p[0] == "1", p[1], p[3]) else DTask(false, "", it)
}

@Composable
private fun HeroCard(steps: Int, taskFrac: Float) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            now = LocalDateTime.now()
            if (n % 30 == 0) battery = batteryPercent(ctx)
            n++
            delay(1000)
        }
    }
    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
    val wd = weekdayIndex(now.toLocalDate())
    val pal = PaletteState.colors
    GlassCard(Modifier.fillMaxWidth()) {
        Text(tr("داشبورد", "Dashboard"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(tr("خلاصه امروز", "Resume of the day."), fontSize = 12.sp)
        Gap(4)
        Text(timeWords(now.hour, now.minute), fontSize = 15.sp, fontWeight = FontWeight.Light)
        Text("${weekdayNames[wd]} ${fa(j.third)} ${monthNames[j.second - 1]} ${fa(j.first)}", fontSize = 12.sp)
        Gap(8)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            MiniRing(steps / 8000f, fa(steps), tr("قدم", "Steps"), pal[4])
            MiniRing(battery / 100f, if (battery >= 0) fa(battery) + "%" else "—", tr("باتری", "Battery"), pal[0])
            MiniRing(taskFrac, fa((taskFrac * 100).roundToInt()) + "%", tr("کارها", "Tasks"), pal[1])
        }
    }
}

@Composable
fun DashboardSection(nav: NavController, weather: Weather?, btc: List<Float>) {
    val pal = PaletteState.colors
    val today = LocalDate.now()
    val sp = NavaStore.sp()
    val steps = sp.getInt("stepsday_$today", 0)
    val week = (6 downTo 0).map { sp.getInt("stepsday_${today.minusDays(it.toLong())}", 0).toFloat() }
    val tasks = todayTasks()
    val taskFrac = if (tasks.isEmpty()) 0f else tasks.count { it.done }.toFloat() / tasks.size
    val msgs = NavaStore.messages.take(2)

    Column(Modifier.fillMaxWidth()) {
    HeroCard(steps, taskFrac)
    Gap(8)
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DashPanel(tr("سلامت", "Health"), "heart", pal[2], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("health") }) {
            Text(fa(steps), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(tr("قدم · ", "steps · ") + fa((steps * 0.04f).toInt()) + " kcal", fontSize = 11.sp)
            PulseLine(week, pal[2], Modifier.fillMaxWidth().height(40.dp))
        }
        DashPanel(tr("هوا", "Weather"), weather?.let { weatherInfo(it.code).first } ?: "cloud", pal[1], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("weather") }) {
            if (weather == null) {
                Text("…", fontSize = 22.sp)
            } else {
                Text(fa(weather.temp.roundToInt()) + "°C", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(weatherInfo(weather.code).second, fontSize = 11.sp)
                Text(tr("باد ", "Wind ") + fa(weather.wind.roundToInt()) + " km/h", fontSize = 11.sp)
            }
        }
    }
    Gap(8)
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DashPanel(tr("پیام‌ها", "Messages"), "chat", pal[0], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("messages") }) {
            Text(fa(NavaStore.messages.size), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (msgs.isEmpty()) Text(tr("پیامی نیست", "No messages"), fontSize = 11.sp)
            for (m in msgs) Text("${m.sender}: ${m.text}", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DashPanel(tr("برنامه امروز", "Today"), "calendar", pal[1], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("calendar") }) {
            if (tasks.isEmpty()) Text(tr("برنامه‌ای نیست", "Nothing planned"), fontSize = 11.sp)
            for (t in tasks.take(3)) {
                Text(
                    "• " + (if (t.from.isNotEmpty()) fa(t.from) + " " else "") + t.title,
                    fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None
                )
            }
        }
    }
    Gap(8)
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DashPanel(tr("ترکینگ", "Tracking"), "map", pal[2], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("tracking") }) {
            Text(if (NavaStore.tracking) tr("در حال ثبت", "Recording") else tr("متوقف", "Idle"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(tr("نقطه: ", "Points: ") + fa(NavaStore.trackPoints.size), fontSize = 11.sp)
            Text(tr("رویداد: ", "Events: ") + fa(NavaStore.events.size), fontSize = 11.sp)
        }
        DashPanel(tr("بازار", "Markets"), "chart", pal[4], Modifier.weight(1f).fillMaxHeight(), { nav.navigate("markets") }) {
            Text(if (btc.isNotEmpty()) "$" + fa(btc.last().roundToInt()) else "…", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("BTC/USD", fontSize = 11.sp)
            if (btc.size > 1) PulseLine(btc, pal[4], Modifier.fillMaxWidth().height(40.dp))
        }
    }
}
}
