package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import org.json.JSONObject

@Composable
private fun AppCell(a: AppInfo, onOpen: () -> Unit, onLong: () -> Unit) {
    Column(
        Modifier
            .pointerInput(a.pkg) { detectTapGestures(onTap = { onOpen() }, onLongPress = { onLong() }) }
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(a.icon, contentDescription = a.label, modifier = Modifier.size(50.dp))
        Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

/** همه اپ‌ها در یک پنل: تب دسته‌ها + جستجو + شبکه با اسکرول مستقل */
@Composable
private fun AppsPanel(
    apps: List<AppInfo>, ov: Map<String, String>,
    onOpen: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit
) {
    var tab by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    val groups = remember(apps, ov) { apps.groupBy { ov[it.pkg] ?: it.cat } }
    val keys = remember(groups) {
        val order = builtinCats.map { it.first }.filter { it != "other" }
        groups.keys.sortedWith(
            compareBy<String>({ if (it == "other") 2 else if (order.contains(it)) 0 else 1 }, { order.indexOf(it) }, { it })
        )
    }
    val cur = if (tab == "all" || groups.containsKey(tab)) tab else "all"
    val list = remember(apps, groups, cur, query) {
        val base = if (cur == "all") apps else (groups[cur] ?: emptyList())
        if (query.isEmpty()) base else base.filter { it.label.contains(query, ignoreCase = true) }
    }
    val pal = PaletteState.colors
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ico("pie", pal[4], 18.dp)
            Text(
                tr("اپ‌ها", "Apps") + " · " + fa(list.size),
                Modifier.padding(horizontal = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 13.sp
            )
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            leadingIcon = { Ico("search", MaterialTheme.colorScheme.onBackground, 20.dp) },
            placeholder = { Text(tr("جستجو...", "Search...")) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            for (k in listOf("all") + keys) {
                val sel = k == cur
                Column(
                    Modifier.clickable { tab = k }.padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (k == "all") tr("همه", "All") else catLabel(k),
                        fontSize = 13.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        color = if (sel) pal[4] else MaterialTheme.colorScheme.onBackground
                    )
                    Box(Modifier.padding(top = 4.dp).size(width = 22.dp, height = 2.dp).background(if (sel) pal[4] else Color.Transparent))
                }
            }
        }
        Box(Modifier.padding(vertical = 4.dp).fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.2f)))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxWidth().height(460.dp)) {
            items(list, key = { it.pkg }) { a ->
                AppCell(a, { onOpen(a) }, { onLong(a) })
            }
        }
    }
}

@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var btc by remember { mutableStateOf<List<Float>>(emptyList()) }
    var moving by remember { mutableStateOf<AppInfo?>(null) }
    var newCat by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    LaunchedEffect(Unit) {
        val loc = bestLocation(ctx)
        weather = fetchWeather(loc.first, loc.second)
    }
    LaunchedEffect(Unit) {
        val t = httpGet("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1")
        if (t != null) {
            try {
                val arr = JSONObject(t).getJSONArray("prices")
                val out = mutableListOf<Float>()
                var i = 0
                while (i < arr.length()) {
                    out.add(arr.getJSONArray(i).getDouble(1).toFloat())
                    i += 12
                }
                btc = out
            } catch (e: Exception) {
            }
        }
    }

    val ov = NavaStore.catOverrides.toMap()

    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        item { Gap(8) }
        item { QuickAccessBar(nav) }
        item { Gap(10) }
        item { DashboardSection(nav, weather, btc) }
        item { Gap(10) }
        item { AppsPanel(apps, ov, { openApp(ctx, it.pkg) }, { moving = it }) }
        item { Gap(32) }
    }

    val m = moving
    if (m != null) {
        val cats = (builtinCats.map { it.first } + apps.map { ov[it.pkg] ?: it.cat }).distinct()
        AlertDialog(
            onDismissRequest = { moving = null },
            confirmButton = { TextButton(onClick = { moving = null }) { Text(tr("بستن", "Close")) } },
            title = { Text(m.label) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tr("انتقال به دسته:", "Move to:"), fontSize = 12.sp)
                    for (c in cats) {
                        Text(
                            catLabel(c),
                            Modifier.fillMaxWidth().clickable { NavaStore.setCategory(m.pkg, c); moving = null }.padding(10.dp)
                        )
                    }
                    OutlinedTextField(
                        value = newCat, onValueChange = { newCat = it }, singleLine = true,
                        placeholder = { Text(tr("دسته جدید...", "New category...")) }
                    )
                    TextButton(onClick = {
                        if (newCat.isNotBlank()) {
                            NavaStore.setCategory(m.pkg, newCat.trim())
                            newCat = ""
                            moving = null
                        }
                    }) { Text(tr("ساخت و انتقال", "Create & move")) }
                }
            }
        )
    }
}
