package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import kotlin.math.roundToInt

@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var usage by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var query by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
    var weather by remember { mutableStateOf<Weather?>(null) }

    LaunchedEffect(Unit) {
        apps = loadApps(ctx)
        usage = withContext(Dispatchers.Default) {
            try {
                if (hasUsageAccess(ctx)) usageToday(ctx) else emptyMap()
            } catch (e: Exception) {
                emptyMap()
            }
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            battery = batteryPercent(ctx)
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        val loc = bestLocation(ctx)
        weather = fetchWeather(loc.first, loc.second)
    }

    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
    val wd = weekdayIndex(now.toLocalDate())
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }
    val dock = remember(apps, usage) {
        if (usage.isNotEmpty()) apps.sortedByDescending { usage[it.pkg] ?: 0L }.take(5) else apps.take(5)
    }
    val routes = listOf(
        "tracking" to "🗺 ترکینگ", "calendar" to "📅 تقویم", "messages" to "💬 پیام‌ها",
        "health" to "❤️ سلامت", "weather" to "⛅ هوا", "markets" to "📈 بازارها",
        "music" to "🎵 موزیک", "usage" to "📊 آمار", "assistant" to "🤖 دستیار", "settings" to "⚙️ تنظیمات"
    )

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text(timeWords(now.hour, now.minute), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(fa("%02d:%02d".format(now.hour, now.minute)), fontSize = 38.sp)
            Text("${weekdayNames[wd]} ${fa(j.third)} ${monthNames[j.second - 1]} ${fa(j.first)}", fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                val t = weather
                Text("🌡 " + (if (t != null) fa(t.temp.roundToInt()) + "°" else "—"))
                Text("🔋 " + (if (battery >= 0) fa(battery) + "٪" else "—"))
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("جستجوی اپ‌ها") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            for (r in routes) NavChip(r.second) { nav.navigate(r.first) }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            items(filtered, key = { it.pkg }) { a ->
                Column(
                    Modifier.clickable { openApp(ctx, a.pkg) }.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(a.icon, contentDescription = null, modifier = Modifier.size(52.dp))
                    Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                }
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (a in dock) {
                    Image(
                        a.icon, contentDescription = a.label,
                        modifier = Modifier.size(54.dp).clickable { openApp(ctx, a.pkg) }
                    )
                }
            }
        }
    }
}
