package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import kotlin.math.roundToInt

@Composable
private fun AppCell(a: AppInfo, modifier: Modifier, onOpen: () -> Unit, onLong: () -> Unit) {
    Column(
        modifier
            .pointerInput(a.pkg) { detectTapGestures(onTap = { onOpen() }, onLongPress = { onLong() }) }
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(a.icon, contentDescription = a.label, modifier = Modifier.size(52.dp))
        Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun AppRow(row: List<AppInfo>, onOpen: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.10f)).padding(horizontal = 8.dp)) {
        for (a in row) AppCell(a, Modifier.weight(1f), { onOpen(a) }, { onLong(a) })
        for (i in row.size until 4) Spacer(Modifier.weight(1f))
    }
}

/** ساعت جدا شده تا هر ثانیه کل صفحه دوباره ساخته نشود */
@Composable
private fun ClockCard() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            now = LocalDateTime.now()
            if (n % 30 == 0) battery = batteryPercent(ctx)
            n++
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        val loc = bestLocation(ctx)
        weather = fetchWeather(loc.first, loc.second)
    }
    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
    val wd = weekdayIndex(now.toLocalDate())
    val pal = PaletteState.colors
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(timeWords(now.hour, now.minute), fontSize = 24.sp, fontWeight = FontWeight.Light)
                Text("${weekdayNames[wd]} ${fa(j.third)} ${monthNames[j.second - 1]} ${fa(j.first)}", fontSize = 13.sp)
                val t = weather
                if (t != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Ico(weatherInfo(t.code).first, pal[1], 20.dp)
                        Spacer(Modifier.size(6.dp))
                        Text(fa(t.temp.roundToInt()) + "°", fontSize = 14.sp)
                    }
                }
            }
            Text(
                if (battery >= 0) fa(battery) + "%" else "—",
                fontSize = 46.sp, fontWeight = FontWeight.ExtraLight
            )
        }
    }
}

@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var collapsed by remember { mutableStateOf<Set<String>>(emptySet()) }
    var moving by remember { mutableStateOf<AppInfo?>(null) }
    var newCat by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { apps = loadApps(ctx) }

    val pal = PaletteState.colors
    val ov = NavaStore.catOverrides.toMap()
    val groups = remember(apps, ov) { apps.groupBy { ov[it.pkg] ?: it.cat } }
    val keys = remember(groups) {
        val order = builtinCats.map { it.first }.filter { it != "other" }
        groups.keys.sortedWith(
            compareBy<String>({ if (it == "other") 2 else if (order.contains(it)) 0 else 1 }, { order.indexOf(it) }, { it })
        )
    }
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    val routes = listOf(
        Triple("tracking", "map", tr("ترکینگ", "Track")),
        Triple("calendar", "calendar", tr("تقویم", "Calendar")),
        Triple("messages", "chat", tr("پیام‌ها", "Messages")),
        Triple("health", "heart", tr("سلامت", "Health")),
        Triple("weather", "cloud", tr("هوا", "Weather")),
        Triple("markets", "chart", tr("بازار", "Markets")),
        Triple("music", "music", tr("موزیک", "Music")),
        Triple("usage", "pie", tr("آمار", "Usage")),
        Triple("assistant", "bot", tr("دستیار", "Assistant")),
        Triple("settings", "gear", tr("تنظیمات", "Settings"))
    )

    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        item { Gap(8) }
        item { ClockCard() }
        item { Gap(8) }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                for ((i, r) in routes.withIndex()) {
                    Column(Modifier.padding(end = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        GlassIconButton(r.second, if (i % 5 == 3) pal[4] else pal[i % 5], { nav.navigate(r.first) }, 50)
                        Text(r.third, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                leadingIcon = { Ico("search", MaterialTheme.colorScheme.onBackground, 20.dp) },
                placeholder = { Text(tr("جستجوی اپ‌ها", "Search apps")) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            )
        }
        if (query.isNotEmpty()) {
            items(filtered.chunked(4)) { row ->
                AppRow(row, { openApp(ctx, it.pkg) }, { moving = it })
            }
        } else {
            for (k in keys) {
                val list = groups[k] ?: emptyList()
                val isOpen = !collapsed.contains(k)
                item(key = "h_$k") {
                    GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                collapsed = if (isOpen) collapsed + k else collapsed - k
                            },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(catLabel(k), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(fa(list.size), fontSize = 12.sp)
                            Spacer(Modifier.size(6.dp))
                            Ico(if (isOpen) "chev_up" else "chev_down", MaterialTheme.colorScheme.onBackground, 20.dp)
                        }
                    }
                }
                if (isOpen) {
                    items(list.chunked(4), key = { "${k}_${it.first().pkg}" }) { row ->
                        AppRow(row, { openApp(ctx, it.pkg) }, { moving = it })
                    }
                }
            }
        }
        item { Gap(32) }
    }

    val m = moving
    if (m != null) {
        val cats = (builtinCats.map { it.first } + apps.map { ov[it.pkg] ?: it.cat }).distinct()
        AlertDialog(
            onDismissRequest = { moving = null },
            confirmButton = { TextButton(onClick = { moving = null }) { Text(tr("بستن", "Close")) } },
            title = { Text(m.label) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tr("انتقال به دسته:", "Move to:"), fontSize = 12.sp)
                    for (c in cats) {
                        Text(
                            catLabel(c),
                            Modifier.fillMaxWidth().clickable { NavaStore.setCategory(m.pkg, c); moving = null }.padding(10.dp)
                        )
                    }
                    OutlinedTextField(
                        value = newCat, onValueChange = { newCat = it }, singleLine = true,
                        placeholder = { Text(tr("دسته جدید...", "New category...")) }
                    )
                    TextButton(onClick = {
                        if (newCat.isNotBlank()) {
                            NavaStore.setCategory(m.pkg, newCat.trim())
                            newCat = ""
                            moving = null
                        }
                    }) { Text(tr("ساخت و انتقال", "Create & move")) }
                }
            }
        )
    }
}
