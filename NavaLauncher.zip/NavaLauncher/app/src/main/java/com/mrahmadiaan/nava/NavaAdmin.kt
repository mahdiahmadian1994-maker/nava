package com.mrahmadiaan.nava

import android.app.admin.DeviceAdminReceiver

class NavaAdmin : DeviceAdminReceiver()
