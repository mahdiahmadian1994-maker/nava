package com.mrahmadiaan.nava.ui

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Track(val id: Long, val title: String, val artist: String)

private fun queryTracks(ctx: Context): List<Track> {
    val out = mutableListOf<Track>()
    val c = ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} ASC"
    ) ?: return out
    c.use {
        while (it.moveToNext()) {
            out.add(Track(it.getLong(0), it.getString(1) ?: "—", it.getString(2) ?: "—"))
        }
    }
    return out
}

private fun mmss(ms: Float): String {
    val s = (ms / 1000).toInt()
    return fa("%d:%02d".format(s / 60, s % 60))
}

@Composable
fun MusicPlayerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val pal = PaletteState.colors
    val fg = MaterialTheme.colorScheme.onBackground
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(hasPerm(ctx, perm)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var idx by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }
    var dur by remember { mutableStateOf(1f) }
    var vol by remember { mutableStateOf(0.8f) }
    var angle by remember { mutableStateOf(0f) }
    var phase by remember { mutableStateOf(0f) }
    val mp = remember { MediaPlayer() }

    fun play(i: Int) {
        if (tracks.isEmpty()) return
        val n = (i + tracks.size) % tracks.size
        idx = n
        try {
            mp.reset()
            mp.setDataSource(ctx, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, tracks[n].id))
            mp.prepare()
            mp.setVolume(vol, vol)
            mp.start()
            dur = mp.duration.toFloat().coerceAtLeast(1f)
            pos = 0f
            loaded = true
            playing = true
        } catch (e: Exception) {
            playing = false
        }
    }

    fun nextIndex(): Int = if (repeat) idx else if (shuffle && tracks.size > 1) Random.nextInt(tracks.size) else idx + 1

    DisposableEffect(Unit) {
        mp.setOnCompletionListener { play(nextIndex()) }
        onDispose {
            try { mp.release() } catch (e: Exception) { }
        }
    }
    LaunchedEffect(granted) {
        if (granted) tracks = withContext(Dispatchers.IO) { queryTracks(ctx) }
    }
    LaunchedEffect(playing) {
        while (playing) {
            try { pos = mp.currentPosition.toFloat() } catch (e: Exception) { }
            delay(500)
        }
    }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                withFrameNanos { it }
                angle = (angle + 0.7f) % 360f
                phase += 0.12f
            }
        }
    }

    val cur = tracks.getOrNull(idx)
    val hue1 = pal[((cur?.id ?: 0L) % 5).toInt()]
    val hue2 = pal[(((cur?.id ?: 0L) + 2) % 5).toInt()]

    ScreenFrame(tr("موزیک‌پلیر", "Music Player"), nav) {
        GlassCard(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                // قوس پیشرفت دور دیسک + دیسک‌های بعدی (مثل نمونه)
                Canvas(Modifier.fillMaxSize()) {
                    val cx = size.width / 2
                    val cy = size.height * 0.56f
                    val r = size.minDimension * 0.30f
                    drawCircle(pal[1].copy(alpha = 0.55f), r * 0.72f, Offset(cx, cy - r * 1.45f))
                    drawCircle(pal[2].copy(alpha = 0.7f), r * 0.86f, Offset(cx, cy - r * 0.95f))
                    val ar = r + 22f
                    val tl = Offset(cx - ar, cy - ar)
                    val sz = Size(ar * 2, ar * 2)
                    drawArc(fg.copy(alpha = 0.2f), 135f, 270f, false, tl, sz, style = Stroke(5f, cap = StrokeCap.Round))
                    val frac = (pos / dur).coerceIn(0f, 1f)
                    drawArc(pal[4], 135f, 270f * frac, false, tl, sz, style = Stroke(5f, cap = StrokeCap.Round))
                    val ang = Math.toRadians((135f + 270f * frac).toDouble())
                    drawCircle(pal[4], 9f, Offset(cx + ar * cos(ang).toFloat(), cy + ar * sin(ang).toFloat()))
                }
                Box(Modifier.size(180.dp).graphicsLayer { rotationZ = angle }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawCircle(Brush.sweepGradient(listOf(hue1, hue2, hue1)))
                        drawCircle(Color(0xFF12172B), radius = size.minDimension * 0.34f)
                        drawCircle(hue1, radius = size.minDimension * 0.12f)
                        drawCircle(Color(0xFF12172B), radius = size.minDimension * 0.03f)
                        drawLine(Color.White.copy(alpha = 0.5f), Offset(size.width / 2, 0f), Offset(size.width / 2, size.height * 0.12f), 4f)
                    }
                }
            }
            Text(
                cur?.title ?: tr("آهنگی انتخاب نشده", "Nothing selected"),
                Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
            Text(cur?.artist ?: "", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 13.sp)
            Gap(6)
            Canvas(Modifier.fillMaxWidth().height(44.dp)) {
                val n = 28
                val bw = size.width / (n * 1.6f)
                for (i in 0 until n) {
                    val f = if (playing) 0.15f + 0.85f * kotlin.math.abs(sin(phase + i * 0.5f) * cos(phase * 0.7f + i * 0.3f)) else 0.08f
                    val hh = size.height * f
                    val x = i * (size.width / n) + bw / 2
                    drawLine(pal[0], Offset(x, size.height / 2 - hh / 2), Offset(x, size.height / 2 + hh / 2), bw)
                }
            }
            Slider(
                value = pos.coerceIn(0f, dur),
                onValueChange = { pos = it },
                onValueChangeFinished = { if (loaded) mp.seekTo(pos.toInt()) },
                valueRange = 0f..dur
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(mmss(pos), fontSize = 12.sp)
                Text(mmss(dur), fontSize = 12.sp)
            }
            Gap(6)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable { shuffle = !shuffle }.padding(8.dp)) { Ico("shuffle", if (shuffle) pal[4] else fg, 24.dp) }
                Box(Modifier.clickable { play(idx - 1) }.padding(8.dp)) { Ico("prev", fg, 28.dp) }
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(fg).clickable {
                        if (!loaded) {
                            play(idx)
                        } else if (playing) {
                            mp.pause()
                            playing = false
                        } else {
                            mp.start()
                            playing = true
                        }
                    },
                    contentAlignment = Alignment.Center
                ) { Ico(if (playing) "pause" else "play", MaterialTheme.colorScheme.background, 30.dp) }
                Box(Modifier.clickable { play(nextIndex()) }.padding(8.dp)) { Ico("next", fg, 28.dp) }
                Box(Modifier.clickable { repeat = !repeat }.padding(8.dp)) { Ico("repeat", if (repeat) pal[4] else fg, 24.dp) }
            }
            Slider(value = vol, onValueChange = { vol = it; mp.setVolume(it, it) })
        }
        Gap(10)
        if (!granted) {
            Button(onClick = { launcher.launch(perm) }) { Text(tr("اجازه دسترسی به آهنگ‌ها", "Allow music access")) }
        } else if (tracks.isEmpty()) {
            Text(tr("آهنگی در گوشی پیدا نشد.", "No music found on device."))
        }
        for ((i, t) in tracks.take(60).withIndex()) {
            Text(
                "${fa(i + 1)}. ${t.title} — ${t.artist}",
                modifier = Modifier.fillMaxWidth().clickable { play(i) }.padding(vertical = 8.dp),
                fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
