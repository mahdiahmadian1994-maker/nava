package com.mrahmadiaan.nava.ui

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class Track(val id: Long, val title: String, val artist: String)

private fun queryTracks(ctx: Context): List<Track> {
    val out = mutableListOf<Track>()
    val c = ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
        arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} ASC"
    ) ?: return out
    c.use {
        while (it.moveToNext()) {
            out.add(Track(it.getLong(0), it.getString(1) ?: "—", it.getString(2) ?: "—"))
        }
    }
    return out
}

private fun mmss(ms: Float): String {
    val s = (ms / 1000).toInt()
    return fa("%d:%02d".format(s / 60, s % 60))
}

@Composable
fun MusicPlayerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(hasPerm(ctx, perm)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var idx by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }
    var dur by remember { mutableStateOf(1f) }
    var vol by remember { mutableStateOf(0.8f) }
    var angle by remember { mutableStateOf(0f) }
    var phase by remember { mutableStateOf(0f) }
    val mp = remember { MediaPlayer() }

    fun play(i: Int) {
        if (tracks.isEmpty()) return
        val n = (i + tracks.size) % tracks.size
        idx = n
        try {
            mp.reset()
            mp.setDataSource(ctx, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, tracks[n].id))
            mp.prepare()
            mp.setVolume(vol, vol)
            mp.start()
            dur = mp.duration.toFloat().coerceAtLeast(1f)
            pos = 0f
            loaded = true
            playing = true
        } catch (e: Exception) {
            playing = false
        }
    }

    DisposableEffect(Unit) {
        mp.setOnCompletionListener { play(idx + 1) }
        onDispose {
            try { mp.release() } catch (e: Exception) { }
        }
    }
    LaunchedEffect(granted) {
        if (granted) tracks = withContext(Dispatchers.IO) { queryTracks(ctx) }
    }
    LaunchedEffect(playing) {
        while (playing) {
            try { pos = mp.currentPosition.toFloat() } catch (e: Exception) { }
            delay(300)
        }
    }
    LaunchedEffect(playing) {
        if (playing) {
            while (true) {
                withFrameNanos { it }
                angle = (angle + 0.7f) % 360f
                phase += 0.12f
            }
        }
    }

    ScreenFrame("موزیک‌پلیر", nav) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF12172B)).padding(16.dp)) {
            CompositionLocalProvider(LocalContentColor provides Color.White) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(200.dp).rotate(angle), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawCircle(Brush.sweepGradient(listOf(Pal.terracotta, Pal.mustard, Pal.green, Pal.terracotta)))
                            drawCircle(Color(0xFF12172B), radius = size.minDimension * 0.33f)
                            drawCircle(Pal.mustard, radius = size.minDimension * 0.12f)
                            drawCircle(Color(0xFF12172B), radius = size.minDimension * 0.03f)
                            drawLine(Color.White.copy(alpha = 0.5f), Offset(size.width / 2, 0f), Offset(size.width / 2, size.height * 0.12f), 4f)
                        }
                    }
                    Gap(8)
                    Text(tracks.getOrNull(idx)?.title ?: "آهنگی انتخاب نشده", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(tracks.getOrNull(idx)?.artist ?: "", fontSize = 13.sp)
                    Gap(8)
                    Canvas(Modifier.fillMaxWidth().height(50.dp)) {
                        val n = 28
                        val bw = size.width / (n * 1.6f)
                        for (i in 0 until n) {
                            val f = if (playing) 0.15f + 0.85f * abs(sin(phase + i * 0.5f) * cos(phase * 0.7f + i * 0.3f)) else 0.08f
                            val hh = size.height * f
                            val x = i * (size.width / n) + bw / 2
                            drawLine(Pal.mint, Offset(x, size.height / 2 - hh / 2), Offset(x, size.height / 2 + hh / 2), bw)
                        }
                    }
                    Slider(
                        value = pos.coerceIn(0f, dur),
                        onValueChange = { pos = it },
                        onValueChangeFinished = { if (loaded) mp.seekTo(pos.toInt()) },
                        valueRange = 0f..dur
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(mmss(pos), fontSize = 12.sp)
                        Text(mmss(dur), fontSize = 12.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { play(idx - 1) }) { Text("⏮", fontSize = 26.sp) }
                        Button(onClick = {
                            if (!loaded) {
                                play(idx)
                            } else if (playing) {
                                mp.pause()
                                playing = false
                            } else {
                                mp.start()
                                playing = true
                            }
                        }) { Text(if (playing) "⏸ توقف" else "▶ پخش", fontSize = 16.sp) }
                        TextButton(onClick = { play(idx + 1) }) { Text("⏭", fontSize = 26.sp) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔊")
                        Slider(
                            value = vol,
                            onValueChange = { vol = it; mp.setVolume(it, it) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
        Gap(10)
        if (!granted) {
            Button(onClick = { launcher.launch(perm) }) { Text("اجازه دسترسی به آهنگ‌ها") }
        } else if (tracks.isEmpty()) {
            Text("آهنگی در گوشی پیدا نشد.")
        }
        for ((i, t) in tracks.take(60).withIndex()) {
            Text(
                "${fa(i + 1)}. ${t.title} — ${t.artist}",
                modifier = Modifier.fillMaxWidth().clickable { play(i) }.padding(vertical = 8.dp),
                fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
