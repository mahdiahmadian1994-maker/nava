package com.mrahmadiaan.nava

import android.app.KeyguardManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrahmadiaan.nava.ui.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime

private val ORANGE = Color(0xFFF77800)
private val SLATE = Color(0xFF454D5A)
private val BEIGE = Color(0xFFD3CBBB)

@Composable
private fun LockContent(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            now = LocalDateTime.now()
            if (n % 20 == 0) battery = batteryPercent(ctx)
            n++
            delay(1000)
        }
    }
    LaunchedEffect(Unit) {
        val loc = bestLocation(ctx)
        weather = fetchWeather(loc.first, loc.second)
    }
    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
    val wd = weekdayIndex(now.toLocalDate())

    Box(Modifier.fillMaxSize().background(BEIGE).clickable { onUnlock() }) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(SLATE, size = androidx.compose.ui.geometry.Size(w, h * 0.78f))
            val orange = Path().apply {
                moveTo(0f, 0f)
                lineTo(w, 0f)
                lineTo(w, h * 0.36f)
                lineTo(w * 0.36f, h * 0.47f)
                quadraticBezierTo(0f, h * 0.53f, 0f, h * 0.42f)
                close()
            }
            drawPath(orange, ORANGE)
            val beige = Path().apply {
                moveTo(0f, h)
                lineTo(0f, h * 0.80f)
                cubicTo(w * 0.35f, h * 0.80f, w * 0.45f, h * 0.64f, w * 0.72f, h * 0.64f)
                cubicTo(w * 0.9f, h * 0.64f, w, h * 0.69f, w, h * 0.73f)
                lineTo(w, h)
                close()
            }
            drawPath(beige, BEIGE)
        }
        Text(
            fa("%02d:%02d".format(now.hour, now.minute)),
            color = Color.White,
            fontSize = 112.sp,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = 2.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 22.dp, top = 80.dp)
                .graphicsLayer { scaleY = 1.7f; transformOrigin = TransformOrigin(0f, 0f) }
        )
        Column(Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 56.dp)) {
            Text(
                "${weekdayNames[wd]} · ${fa(j.third)} ${monthNames[j.second - 1]}",
                color = SLATE, fontSize = 13.sp
            )
            Text(
                (if (battery >= 0) fa(battery) else "—") + "%",
                color = SLATE, fontSize = 20.sp, fontWeight = FontWeight.Medium
            )
            Box(Modifier.padding(top = 8.dp).width(220.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(SLATE.copy(alpha = 0.25f))) {
                Box(Modifier.fillMaxWidth(battery.coerceIn(0, 100) / 100f).height(5.dp).background(SLATE))
            }
            Text(tr("برای ورود لمس کنید", "Tap to unlock"), color = SLATE, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        }
        val w = weather
        if (w != null) {
            Row(Modifier.align(Alignment.BottomEnd).padding(end = 28.dp, bottom = 60.dp), verticalAlignment = Alignment.CenterVertically) {
                Ico(weatherInfo(w.code).first, SLATE, 26.dp)
                Text("  " + fa(w.temp.toInt()) + "°", color = SLATE, fontSize = 16.sp)
            }
        }
    }
}

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setContent {
            NavaTheme {
                LockContent { unlock() }
            }
        }
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km != null && km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finish()
                }
            })
        } else {
            finish()
        }
    }
}
