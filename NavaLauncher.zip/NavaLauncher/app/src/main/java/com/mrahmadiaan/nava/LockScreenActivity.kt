package com.mrahmadiaan.nava

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrahmadiaan.nava.ui.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        setContent {
            NavaTheme {
                ParticleLayer {
                    val ctx = LocalContext.current
                    var now by remember { mutableStateOf(LocalDateTime.now()) }
                    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            now = LocalDateTime.now()
                            battery = batteryPercent(ctx)
                            delay(1000)
                        }
                    }
                    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
                    val wd = weekdayIndex(now.toLocalDate())
                    Column(
                        Modifier.fillMaxSize().clickable { finish() }.padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            fa("%02d:%02d".format(now.hour, now.minute)),
                            fontSize = 84.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(timeWords(now.hour, now.minute), fontSize = 20.sp)
                        Gap(12)
                        GlassCard(Modifier.fillMaxWidth()) {
                            Text("${weekdayNames[wd]} ${fa(j.third)} ${monthNames[j.second - 1]} ${fa(j.first)}", fontSize = 18.sp)
                            Text("🔋 ${fa(battery)}٪", fontSize = 16.sp)
                        }
                        Gap(24)
                        Text("برای ورود لمس کنید", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
