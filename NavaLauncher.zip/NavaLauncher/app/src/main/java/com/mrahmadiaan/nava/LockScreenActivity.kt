package com.mrahmadiaan.nava

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mrahmadiaan.nava.ui.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        setContent {
            NavaTheme {
                ParticleLayer {
                    val ctx = LocalContext.current
                    var now by remember { mutableStateOf(LocalDateTime.now()) }
                    var battery by remember { mutableStateOf(batteryPercent(ctx)) }
                    var weather by remember { mutableStateOf<Weather?>(null) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            now = LocalDateTime.now()
                            battery = batteryPercent(ctx)
                            delay(1000)
                        }
                    }
                    LaunchedEffect(Unit) {
                        val loc = bestLocation(ctx)
                        weather = fetchWeather(loc.first, loc.second)
                    }
                    val j = gregorianToJalali(now.year, now.monthValue, now.dayOfMonth)
                    val wd = weekdayIndex(now.toLocalDate())
                    val pal = PaletteState.colors
                    Column(
                        Modifier.fillMaxSize().clickable { finish() }.padding(28.dp),
                        verticalArrangement = Arrangement.Top
                    ) {
                        Column(Modifier.padding(top = 48.dp)) {
                            val w = weather
                            if (w != null) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Ico(weatherInfo(w.code).first, pal[1], 22.dp)
                                    Text("  " + fa(w.temp.toInt()) + "°", fontSize = 15.sp)
                                }
                            }
                            Text(
                                timeWords(now.hour, now.minute).uppercase(),
                                fontSize = 34.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp,
                                lineHeight = 42.sp
                            )
                            Text(
                                if (battery >= 0) fa(battery) + "%" else "—",
                                fontSize = 72.sp, fontWeight = FontWeight.ExtraLight
                            )
                            Text(
                                "${weekdayNames[wd]} · ${fa(j.third)} ${monthNames[j.second - 1]} ${fa(j.first)}",
                                fontSize = 15.sp
                            )
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Bottom) {
                            Text(
                                buildAnnotatedString {
                                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("Focus on\nthe ") }
                                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = pal[1])) { append("good.") }
                                },
                                fontSize = 30.sp, lineHeight = 36.sp
                            )
                            Text(tr("برای ورود لمس کنید", "Tap to unlock"), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                        }
                    }
                }
            }
        }
    }
}
