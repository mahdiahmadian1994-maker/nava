package com.mrahmadiaan.nava.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

object Pal {
    val cream = Color(0xFFF3EEE4)
    val mint = Color(0xFFCDE3D6)
    val mustard = Color(0xFFE3B448)
    val terracotta = Color(0xFFC97B63)
    val navy = Color(0xFF2B3A55)
    val green = Color(0xFFA8C686)
    val orange = Color(0xFFE88D5A)
}

object PaletteState {
    val default: List<Color> = listOf(Pal.mint, Pal.mustard, Pal.terracotta, Pal.green, Pal.orange)
    var colors: List<Color> by mutableStateOf(default)
}

@Composable
fun NavaTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = PaletteState.colors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c[1], secondary = c[0], tertiary = c[2],
            background = Pal.navy, surface = Pal.navy,
            onPrimary = Pal.navy, onBackground = Color.White, onSurface = Color.White
        )
    } else {
        lightColorScheme(
            primary = c[2], secondary = c[3], tertiary = c[1],
            background = Pal.cream, surface = Pal.cream,
            onPrimary = Color.White, onBackground = Pal.navy, onSurface = Pal.navy
        )
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val dark = isSystemInDarkTheme()
    val base = if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.50f)
    val shape = RoundedCornerShape(24.dp)
    val border = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.8f), Color.White.copy(alpha = 0.1f)))
    var m = modifier.clip(shape).background(base).border(1.dp, border, shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(modifier = m.padding(16.dp), content = content)
}

@Composable
fun NavChip(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(end = 8.dp)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 13.sp)
    }
}

@Composable
fun Gap(h: Int = 8) {
    Spacer(Modifier.height(h.dp))
}

@Composable
fun ScreenFrame(
    title: String,
    nav: NavController,
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
            TextButton(onClick = { nav.popBackStack() }) { Text("→ بازگشت") }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        val m = if (scroll) {
            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())
        } else {
            Modifier.fillMaxWidth().weight(1f)
        }
        Column(m, content = content)
    }
}

private class Particle(
    var x: Float, var y: Float, val vx: Float, val vy: Float,
    val r: Float, val a: Float, val ci: Int
)

@Composable
fun ParticleLayer(content: @Composable BoxScope.() -> Unit) {
    val ps = remember {
        List(36) {
            Particle(
                Random.nextFloat(), Random.nextFloat(),
                (Random.nextFloat() - 0.5f) * 0.03f, (Random.nextFloat() - 0.5f) * 0.03f,
                4f + Random.nextFloat() * 12f, 0.12f + Random.nextFloat() * 0.25f, it % 5
            )
        }
    }
    var tick by remember { mutableStateOf(0L) }
    var touch by remember { mutableStateOf<Offset?>(null) }
    var w by remember { mutableStateOf(1f) }
    var h by remember { mutableStateOf(1f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanosCompat()
        while (true) {
            val now = withFrameNanosCompat()
            val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = now
            val t = touch
            for (p in ps) {
                p.x += p.vx * dt
                p.y += p.vy * dt
                if (t != null) {
                    val dx = p.x * w - t.x
                    val dy = p.y * h - t.y
                    val d = sqrt(dx * dx + dy * dy) + 0.001f
                    if (d < 260f) {
                        val push = (260f - d) / 260f * 500f * dt
                        p.x += dx / d * push / w
                        p.y += dy / d * push / h
                    }
                }
                if (p.x < 0f) p.x += 1f
                if (p.x > 1f) p.x -= 1f
                if (p.y < 0f) p.y += 1f
                if (p.y > 1f) p.y -= 1f
            }
            tick = now
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        val c = e.changes.firstOrNull()
                        touch = if (c != null && c.pressed) c.position else null
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val k = tick
            if (k >= 0L) {
                for (p in ps) {
                    drawCircle(
                        PaletteState.colors[p.ci].copy(alpha = p.a),
                        p.r,
                        Offset(p.x * size.width, p.y * size.height)
                    )
                }
            }
        }
        content()
    }
}

private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
fun pulseScale(): Float {
    val t = rememberInfiniteTransition(label = "pulse")
    val s by t.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
    return s
}

@Composable
fun PulseRing(progress: Float, color: Color, label: String, modifier: Modifier = Modifier.size(120.dp)) {
    val s = pulseScale()
    var drag by remember { mutableStateOf(0f) }
    val d by animateFloatAsState(drag, label = "drag")
    Box(
        modifier
            .scale(s)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { drag = 0f },
                    onDragCancel = { drag = 0f }
                ) { change, amount ->
                    change.consume()
                    drag = (drag + amount.x).coerceIn(-40f, 40f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(14.dp)) {
            val sw = 12f + abs(d) / 3f
            drawArc(color.copy(alpha = 0.2f), 0f, 360f, false, style = Stroke(width = sw, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, style = Stroke(width = sw, cap = StrokeCap.Round))
        }
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PulseLine(values: List<Float>, color: Color, modifier: Modifier = Modifier.fillMaxWidth().height(70.dp)) {
    val s = pulseScale()
    var touchX by remember { mutableStateOf<Float?>(null) }
    Canvas(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { touchX = it.x },
                onDragEnd = { touchX = null },
                onDragCancel = { touchX = null }
            ) { change, _ ->
                change.consume()
                touchX = change.position.x
            }
        }
    ) {
        if (values.size >= 2) {
            val mn = values.min()
            val mx = values.max()
            val range = if (mx - mn > 0f) mx - mn else 1f
            val stepX = size.width / (values.size - 1)
            fun yOf(v: Float): Float = size.height - ((v - mn) / range * 0.8f + 0.1f) * size.height
            val path = Path()
            values.forEachIndexed { i, v ->
                if (i == 0) path.moveTo(0f, yOf(v)) else path.lineTo(i * stepX, yOf(v))
            }
            drawPath(path, color, style = Stroke(width = 4f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
            val tx = touchX
            if (tx != null) {
                val idx = (tx / stepX).roundToInt().coerceIn(0, values.size - 1)
                val x = idx * stepX
                drawLine(color.copy(alpha = 0.4f), Offset(x, 0f), Offset(x, size.height), 2f)
                drawCircle(color, 10f * s, Offset(x, yOf(values[idx])))
            }
        }
    }
}
