package com.mrahmadiaan.nava.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

object Pal {
    val ink = Color(0xFF031A24)
    val deep = Color(0xFF0A3A47)
    val teal = Color(0xFF1F6070)
    val orange = Color(0xFFFF9330)
    val burnt = Color(0xFFC2540C)
    val peach = Color(0xFFE3A06B)
    val cream = Color(0xFFFFF1CF)
    val text = Color(0xFFF6ECE0)
    val mint = Color(0xFFBFDDD2)
    val mustard = Color(0xFFE9AE4B)
    val coral = Color(0xFFE57F68)
    val navy = Color(0xFF2A4B64)
    val paper = Color(0xFFF7F0E8)
}

object PaletteState {
    val default: List<Color> = listOf(Pal.mint, Pal.mustard, Pal.coral, Pal.navy, Pal.orange)
    var colors: List<Color> by mutableStateOf(default)
}

object Lang {
    var fa: Boolean by mutableStateOf(true)
}

fun tr(f: String, e: String): String = if (Lang.fa) f else e

@Composable
fun NavaTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = PaletteState.colors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c[4], secondary = c[0], tertiary = c[1],
            background = Pal.ink, surface = Pal.deep,
            onPrimary = Pal.ink, onBackground = Pal.text, onSurface = Pal.text
        )
    } else {
        lightColorScheme(
            primary = c[2], secondary = c[0], tertiary = c[1],
            background = Pal.paper, surface = Pal.paper,
            onPrimary = Color.White, onBackground = c[3], onSurface = c[3]
        )
    }
    val dir = if (Lang.fa) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** کارت شیشه‌ای مات */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val dark = isSystemInDarkTheme()
    val shape = RoundedCornerShape(28.dp)
    val fill = if (dark) {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Pal.ink.copy(alpha = 0.55f)))
    } else {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.66f), Color.White.copy(alpha = 0.30f)))
    }
    val edge = Brush.linearGradient(
        listOf(Color.White.copy(alpha = if (dark) 0.35f else 0.9f), Color.White.copy(alpha = 0.06f))
    )
    val glow = PaletteState.colors[4]
    var m = modifier
        .clip(shape)
        .background(fill)
        .border(1.dp, edge, shape)
        .drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(glow.copy(alpha = if (dark) 0.22f else 0.14f), Color.Transparent),
                    center = Offset(size.width * 0.85f, 0f),
                    radius = size.width * 0.8f
                )
            )
        }
    if (onClick != null) m = m.clickable { onClick() }
    Column(modifier = m.padding(16.dp), content = content)
}

@Composable
fun NavChip(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(end = 8.dp)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 13.sp)
    }
}

@Composable
fun GlassIconButton(kind: String, tint: Color, onClick: () -> Unit, size: Int = 44) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.18f))
            .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Ico(kind, tint, (size * 0.5f).dp)
    }
}

@Composable
fun Gap(h: Int = 8) {
    Spacer(Modifier.height(h.dp))
}

@Composable
fun ScreenFrame(
    title: String,
    nav: NavController,
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            GlassIconButton("back", MaterialTheme.colorScheme.onBackground, { nav.popBackStack() }, 40)
            Box(Modifier.size(12.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        val m = if (scroll) {
            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())
        } else {
            Modifier.fillMaxWidth().weight(1f)
        }
        Column(m, content = content)
    }
}

private class Particle(
    var x: Float, var y: Float, val vx: Float, val vy: Float,
    val r: Float, val a: Float, val ci: Int
)

private fun DrawScope.wave(y: Float, amp: Float, phase: Float, color: Color) {
    val w = size.width
    val h = size.height
    val p = Path()
    p.moveTo(0f, h)
    p.lineTo(0f, y)
    val steps = 14
    for (i in 0..steps) {
        val x = w * i / steps
        p.lineTo(x, y + amp * sin(i * 0.28f + phase) + amp * 0.6f * sin(i * 0.11f - phase * 0.7f))
    }
    p.lineTo(w, h)
    p.close()
    drawPath(p, color)
}

/** پس‌زمینه: موج‌های کاغذی + بلاب‌های متحرک + ذرات (با واکنش به لمس) */
@Composable
fun ParticleLayer(content: @Composable BoxScope.() -> Unit) {
    val dark = isSystemInDarkTheme()
    val ps = remember {
        List(20) {
            Particle(
                Random.nextFloat(), Random.nextFloat(),
                (Random.nextFloat() - 0.5f) * 0.03f, (Random.nextFloat() - 0.5f) * 0.03f,
                4f + Random.nextFloat() * 12f, 0.10f + Random.nextFloat() * 0.22f, it % 5
            )
        }
    }
    var tick by remember { mutableStateOf(0L) }
    var touch by remember { mutableStateOf<Offset?>(null) }
    var w by remember { mutableStateOf(1f) }
    var h by remember { mutableStateOf(1f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        var acc = 0f
        while (true) {
            val now = withFrameNanos { it }
            acc += (now - last) / 1_000_000_000f
            last = now
            if (acc < 0.032f) continue
            val dt = acc.coerceAtMost(0.06f)
            acc = 0f
            val t = touch
            for (p in ps) {
                p.x += p.vx * dt
                p.y += p.vy * dt
                if (t != null) {
                    val dx = p.x * w - t.x
                    val dy = p.y * h - t.y
                    val d = sqrt(dx * dx + dy * dy) + 0.001f
                    if (d < 260f) {
                        val push = (260f - d) / 260f * 500f * dt
                        p.x += dx / d * push / w
                        p.y += dy / d * push / h
                    }
                }
                if (p.x < 0f) p.x += 1f
                if (p.x > 1f) p.x -= 1f
                if (p.y < 0f) p.y += 1f
                if (p.y > 1f) p.y -= 1f
            }
            tick = now
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        val c = e.changes.firstOrNull()
                        touch = if (c != null && c.pressed) c.position else null
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val k = tick
            val t = (k / 1_000_000_000.0).toFloat()
            val pc = PaletteState.colors
            if (dark) {
                drawRect(Brush.verticalGradient(listOf(Pal.ink, Pal.deep, Color(0xFF0C4552))))
                val c1 = Offset(size.width * 0.1f + sin(t * 0.2f) * size.width * 0.05f, size.height * 0.95f)
                drawCircle(
                    Brush.radialGradient(listOf(Pal.orange.copy(alpha = 0.45f), Color.Transparent), center = c1, radius = size.width * 0.9f),
                    size.width * 0.9f, c1
                )
                val c2 = Offset(size.width * 0.95f, size.height * 0.05f + sin(t * 0.15f) * size.height * 0.02f)
                drawCircle(
                    Brush.radialGradient(listOf(Pal.teal.copy(alpha = 0.55f), Color.Transparent), center = c2, radius = size.width * 0.8f),
                    size.width * 0.8f, c2
                )
            } else {
                drawRect(Pal.paper)
            }
            val a = if (dark) 0.42f else 1f
            val hh = size.height
            wave(hh * 0.86f, 14f, t * 0.35f + 1f, pc[3].copy(alpha = a))
            wave(hh * 0.83f, 14f, t * 0.30f + 2f, pc[2].copy(alpha = a))
            wave(hh * 0.80f, 14f, t * 0.27f + 3f, pc[1].copy(alpha = a))
            wave(hh * 0.77f, 14f, t * 0.24f + 4f, Color(0xFFF4E5CF).copy(alpha = a))
            wave(hh * 0.74f, 14f, t * 0.21f + 5f, pc[0].copy(alpha = a))
            for (p in ps) {
                drawCircle(
                    pc[p.ci].copy(alpha = p.a),
                    p.r,
                    Offset(p.x * size.width, p.y * size.height)
                )
            }
        }
        content()
    }
}

@Composable
fun pulseState(): androidx.compose.runtime.State<Float> {
    val t = rememberInfiniteTransition(label = "pulse")
    return t.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
}

@Composable
fun PulseRing(
    progress: Float,
    color: Color,
    label: String,
    modifier: Modifier = Modifier.size(130.dp),
    progress2: Float? = null,
    color2: Color = color,
    sub: String = ""
) {
    val s = pulseState()
    var drag by remember { mutableStateOf(0f) }
    val d by animateFloatAsState(drag, label = "drag")
    Box(
        modifier
            .graphicsLayer { scaleX = s.value; scaleY = s.value }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { drag = 0f },
                    onDragCancel = { drag = 0f }
                ) { change, amount ->
                    change.consume()
                    drag = (drag + amount.x).coerceIn(-40f, 40f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(12.dp)) {
            val sw = 14f + abs(d) / 3f
            drawArc(color.copy(alpha = 0.2f), 0f, 360f, false, style = Stroke(width = sw, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, style = Stroke(width = sw, cap = StrokeCap.Round))
            if (progress2 != null) {
                val inset = sw * 1.8f
                val tl = Offset(inset, inset)
                val sz = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2)
                drawArc(color2.copy(alpha = 0.2f), 0f, 360f, false, tl, sz, style = Stroke(width = sw, cap = StrokeCap.Round))
                drawArc(color2, -90f, 360f * progress2.coerceIn(0f, 1f), false, tl, sz, style = Stroke(width = sw, cap = StrokeCap.Round))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (sub.isNotEmpty()) Text(sub, fontSize = 10.sp)
        }
    }
}

@Composable
fun PulseLine(values: List<Float>, color: Color, modifier: Modifier = Modifier.fillMaxWidth().height(70.dp)) {
    val s = pulseState()
    var touchX by remember { mutableStateOf<Float?>(null) }
    Canvas(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { touchX = it.x },
                onDragEnd = { touchX = null },
                onDragCancel = { touchX = null }
            ) { change, _ ->
                change.consume()
                touchX = change.position.x
            }
        }
    ) {
        if (values.size >= 2) {
            val mn = values.min()
            val mx = values.max()
            val range = if (mx - mn > 0f) mx - mn else 1f
            val stepX = size.width / (values.size - 1)
            fun yOf(v: Float): Float = size.height - ((v - mn) / range * 0.8f + 0.1f) * size.height
            val path = Path()
            val fill = Path()
            fill.moveTo(0f, size.height)
            values.forEachIndexed { i, v ->
                val x = i * stepX
                if (i == 0) path.moveTo(x, yOf(v)) else path.lineTo(x, yOf(v))
                fill.lineTo(x, yOf(v))
            }
            fill.lineTo(size.width, size.height)
            fill.close()
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
            drawPath(path, color, style = Stroke(width = 4f * s.value, cap = StrokeCap.Round, join = StrokeJoin.Round))
            val tx = touchX
            if (tx != null) {
                val idx = (tx / stepX).roundToInt().coerceIn(0, values.size - 1)
                val x = idx * stepX
                drawLine(color.copy(alpha = 0.4f), Offset(x, 0f), Offset(x, size.height), 2f)
                drawCircle(color, 10f * s.value, Offset(x, yOf(values[idx])))
            }
        }
    }
}
