package com.mrahmadiaan.nava.ui

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.navigation.NavController
import com.mrahmadiaan.nava.MsgItem
import com.mrahmadiaan.nava.NavaStore

fun sendQuickReply(ctx: Context, action: Notification.Action, text: String) {
    val inputs = action.remoteInputs ?: return
    val intent = Intent()
    val bundle = Bundle()
    for (r in inputs) bundle.putCharSequence(r.resultKey, text)
    RemoteInput.addResultsToIntent(inputs, intent, bundle)
    try {
        action.actionIntent.send(ctx, 0, intent)
    } catch (e: PendingIntent.CanceledException) {
    }
}

@Composable
private fun MessageCard(m: MsgItem) {
    val ctx = LocalContext.current
    var txt by remember { mutableStateOf("") }
    val act = m.reply
    GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { openApp(ctx, m.pkg) }) {
        Text(m.appName, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        Text(m.sender, fontWeight = FontWeight.Bold)
        Text(m.text)
        if (act != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = txt, onValueChange = { txt = it }, singleLine = true,
                    placeholder = { Text("پاسخ سریع") }, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    if (txt.isNotBlank()) {
                        sendQuickReply(ctx, act, txt)
                        txt = ""
                    }
                }) { Text("ارسال") }
            }
        }
    }
}

@Composable
fun MessagesScreen(nav: NavController) {
    val ctx = LocalContext.current
    var showPicker by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    val enabled = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    ScreenFrame("پیام‌ها", nav) {
        if (!enabled) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("برای دریافت پیام‌ها باید دسترسی نوتیفیکیشن را فعال کنید.")
                Button(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("فعال‌سازی") }
            }
            Gap(8)
        }
        Text("اپ‌های مجاز (برای حذف لمس کنید)", fontSize = 13.sp)
        Gap(4)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            for (p in NavaStore.allowed.toList()) {
                val label = apps.firstOrNull { it.pkg == p }?.label ?: p
                NavChip("$label ✕") { NavaStore.removeAllowed(p) }
            }
            NavChip("＋ افزودن") { showPicker = true }
        }
        Gap(8)
        val list = NavaStore.messages.toList()
        if (list.isEmpty()) Text("هنوز پیامی دریافت نشده است.")
        for (m in list) MessageCard(m)
    }

    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("بستن") } },
            title = { Text("انتخاب اپ") },
            text = {
                LazyColumn(Modifier.height(400.dp)) {
                    items(apps) { a ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { NavaStore.addAllowed(a.pkg); showPicker = false }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(a.icon, contentDescription = null, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(a.label)
                        }
                    }
                }
            }
        )
    }
}
