package com.mrahmadiaan.nava.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.mrahmadiaan.nava.LocationTrackingService
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import org.json.JSONObject
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class Flight(val call: String, val lat: Double, val lon: Double, val alt: Double, val speed: Double)

private suspend fun fetchFlights(la: Double, lo: Double): List<Flight> {
    val t = httpGet(
        "https://opensky-network.org/api/states/all?lamin=${la - 1.0}&lomin=${lo - 1.5}&lamax=${la + 1.0}&lomax=${lo + 1.5}"
    ) ?: return emptyList()
    return try {
        val arr = JSONObject(t).optJSONArray("states") ?: return emptyList()
        val out = mutableListOf<Flight>()
        for (i in 0 until minOf(arr.length(), 60)) {
            val s = arr.getJSONArray(i)
            if (s.isNull(5) || s.isNull(6)) continue
            val call = s.optString(1, "").trim().ifEmpty { s.optString(0, "?") }
            out.add(Flight(call, s.getDouble(6), s.getDouble(5), s.optDouble(7, 0.0), s.optDouble(9, 0.0)))
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

private fun distKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
    val r = 6371.0
    val dLat = Math.toRadians(b.first - a.first)
    val dLon = Math.toRadians(b.second - a.second)
    val x = sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(a.first)) * cos(Math.toRadians(b.first)) * sin(dLon / 2) * sin(dLon / 2)
    return 2 * r * atan2(sqrt(x), sqrt(1 - x))
}

private fun onWifi(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
}

@Composable
private fun Stat(icon: String, value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Ico(icon, PaletteState.colors[4], 22.dp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(label, fontSize = 11.sp)
    }
}

@Composable
private fun ProgressCard(wifi: Boolean, dlMsg: String, flightCount: Int) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }
    val size = NavaStore.trackPoints.size
    val km = remember(size) {
        var d = 0.0
        val pts = NavaStore.trackPoints.toList()
        for (i in 1 until pts.size) d += distKm(pts[i - 1], pts[i])
        d
    }
    val start = NavaStore.trackStart
    val secs = if (start > 0L) ((nowMs - start) / 1000).coerceAtLeast(0L) else 0L
    val speed = if (secs > 0L) km / (secs / 3600.0) else 0.0
    GlassCard(Modifier.fillMaxWidth()) {
        Text(tr("پیشرفت مسیر", "Trek Progress"), fontWeight = FontWeight.Bold)
        Gap(8)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("map", fa("%.2f".format(km)) + " km", tr("مسافت", "Distance"), Modifier.weight(1f))
            Stat("clock", fa("%02d:%02d".format(secs / 60, secs % 60)), tr("زمان", "Time"), Modifier.weight(1f))
            Stat("speed", fa("%.1f".format(speed)) + " km/h", tr("سرعت", "Speed"), Modifier.weight(1f))
        }
        Gap(8)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ico("wifi", if (wifi) PaletteState.colors[0] else PaletteState.colors[2], 20.dp)
            Text("  $dlMsg", fontSize = 12.sp)
        }
        Text(
            tr("پرواز اطراف: ", "Nearby flights: ") + fa(flightCount) + " · " +
                tr("رویداد: ", "Events: ") + fa(NavaStore.events.size),
            fontSize = 12.sp
        )
    }
}

@Composable
fun TrackingScreen(nav: NavController) {
    val ctx = LocalContext.current
    var flights by remember { mutableStateOf<List<Flight>>(emptyList()) }
    var wifi by remember { mutableStateOf(onWifi(ctx)) }
    var dlMsg by remember { mutableStateOf("") }
    var downloading by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    LaunchedEffect(Unit) {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }
    LaunchedEffect(wifi) {
        if (wifi) {
            val loc = bestLocation(ctx)
            flights = fetchFlights(loc.first, loc.second)
        }
        while (true) {
            delay(30000)
            if (wifi) {
                val loc = bestLocation(ctx)
                flights = fetchFlights(loc.first, loc.second)
            }
        }
    }

    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(14.0)
            val loc = bestLocation(ctx)
            controller.setCenter(GeoPoint(loc.first, loc.second))
        }
    }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
            }

            override fun onLost(network: Network) {
                wifi = false
            }
        }
        try { cm.registerDefaultNetworkCallback(cb) } catch (e: Exception) { }
        mapView.onResume()
        onDispose {
            try { cm.unregisterNetworkCallback(cb) } catch (e: Exception) { }
            mapView.onPause()
            mapView.onDetach()
        }
    }
    // فقط روی Wi-Fi نقشه دانلود می‌شود (حتی اگر کش پاک شده باشد، دوباره پر می‌شود)
    LaunchedEffect(wifi) {
        if (wifi) {
            if (!downloading) {
                try {
                    downloading = true
                    val loc = bestLocation(ctx)
                    val bb = BoundingBox(loc.first + 0.04, loc.second + 0.05, loc.first - 0.04, loc.second - 0.05)
                    dlMsg = tr("در حال همگام‌سازی نقشه آفلاین...", "Syncing offline map...")
                    CacheManager(mapView).downloadAreaAsyncNoUI(ctx, bb, 11, 15, object : CacheManager.CacheManagerCallback {
                        override fun onTaskComplete() {
                            dlMsg = tr("نقشه آفلاین آماده است", "Offline map ready")
                            downloading = false
                        }

                        override fun onTaskFailed(errors: Int) {
                            dlMsg = tr("دانلود نقشه ناقص ماند", "Map download incomplete")
                            downloading = false
                        }

                        override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                        override fun downloadStarted() {}
                        override fun setPossibleTilesInArea(total: Int) {}
                    })
                } catch (e: Exception) {
                    dlMsg = tr("دانلود نقشه ممکن نشد", "Map download failed")
                    downloading = false
                }
            }
        } else {
            dlMsg = tr("دیتای موبایل: فقط نقشه ذخیره‌شده", "Mobile data: cached map only")
        }
    }

    val line = remember {
        Polyline().apply {
            outlinePaint.color = android.graphics.Color.parseColor("#E57F68")
            outlinePaint.strokeWidth = 10f
        }
    }

    ScreenFrame(tr("ترکینگ", "Tracking"), nav) {
        Box(Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(28.dp))) {
            AndroidView(
                factory = {
                    mapView.also {
                        it.overlays.add(line)
                        it.setOnTouchListener { v, _ ->
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                            false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(380.dp),
                update = { m ->
                    m.setUseDataConnection(wifi)
                    line.setPoints(NavaStore.trackPoints.map { GeoPoint(it.first, it.second) })
                    m.overlays.removeAll { it is Marker }
                    for (f in flights) {
                        val mk = Marker(m)
                        mk.position = GeoPoint(f.lat, f.lon)
                        mk.title = f.call
                        mk.snippet = "${f.alt.roundToInt()} m · ${(f.speed * 3.6).roundToInt()} km/h"
                        m.overlays.add(mk)
                    }
                    for (e in NavaStore.events.toList()) {
                        val mk = Marker(m)
                        mk.position = GeoPoint(e.lat, e.lon)
                        mk.title = (if (e.kind == "photo") tr("عکس: ", "Photo: ") else tr("اعلان: ", "Notif: ")) + e.title
                        m.overlays.add(mk)
                    }
                    m.invalidate()
                }
            )
            Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                GlassIconButton("compass", MaterialTheme.colorScheme.onBackground, {
                    val la = NavaStore.lastLat
                    val lo = NavaStore.lastLon
                    if (la != null && lo != null) mapView.controller.animateTo(GeoPoint(la, lo))
                }, 40)
            }
        }
        Gap(10)
        ProgressCard(wifi, dlMsg, flights.size)
        Gap(10)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (hasPerm(ctx, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, LocationTrackingService::class.java))
                } else {
                    permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }) { Text(if (NavaStore.tracking) tr("در حال ثبت", "Recording") else tr("شروع", "Start")) }
            OutlinedButton(onClick = { ctx.stopService(Intent(ctx, LocationTrackingService::class.java)) }) {
                Text(tr("توقف", "Stop"))
            }
            OutlinedButton(onClick = {
                NavaStore.trackPoints.clear()
                NavaStore.trackStart = 0L
            }) { Text(tr("پاک‌کردن", "Clear")) }
        }
    }
}
