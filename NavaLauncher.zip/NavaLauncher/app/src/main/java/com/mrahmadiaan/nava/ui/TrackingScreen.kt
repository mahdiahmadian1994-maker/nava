package com.mrahmadiaan.nava.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.mrahmadiaan.nava.LocationTrackingService
import com.mrahmadiaan.nava.NavaStore
import kotlinx.coroutines.delay
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import kotlin.math.roundToInt

data class Flight(val call: String, val lat: Double, val lon: Double, val alt: Double, val speed: Double)

private suspend fun fetchFlights(la: Double, lo: Double): List<Flight> {
    val t = httpGet(
        "https://opensky-network.org/api/states/all?lamin=${la - 1.0}&lomin=${lo - 1.5}&lamax=${la + 1.0}&lomax=${lo + 1.5}"
    ) ?: return emptyList()
    return try {
        val arr = JSONObject(t).optJSONArray("states") ?: return emptyList()
        val out = mutableListOf<Flight>()
        for (i in 0 until minOf(arr.length(), 60)) {
            val s = arr.getJSONArray(i)
            if (s.isNull(5) || s.isNull(6)) continue
            val call = s.optString(1, "").trim().ifEmpty { s.optString(0, "?") }
            out.add(Flight(call, s.getDouble(6), s.getDouble(5), s.optDouble(7, 0.0), s.optDouble(9, 0.0)))
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun TrackingScreen(nav: NavController) {
    val ctx = LocalContext.current
    var flights by remember { mutableStateOf<List<Flight>>(emptyList()) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    LaunchedEffect(Unit) {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }
    LaunchedEffect(Unit) {
        while (true) {
            val loc = bestLocation(ctx)
            flights = fetchFlights(loc.first, loc.second)
            delay(30000)
        }
    }

    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(13.0)
            val loc = bestLocation(ctx)
            controller.setCenter(GeoPoint(loc.first, loc.second))
        }
    }
    DisposableEffect(Unit) {
        mapView.onResume()
        onDispose {
            mapView.onPause()
            mapView.onDetach()
        }
    }

    ScreenFrame("ترکینگ", nav) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (hasPerm(ctx, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, LocationTrackingService::class.java))
                } else {
                    permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }) { Text("شروع ثبت مسیر") }
            OutlinedButton(onClick = { ctx.stopService(Intent(ctx, LocationTrackingService::class.java)) }) { Text("توقف") }
            OutlinedButton(onClick = {
                val la = NavaStore.lastLat
                val lo = NavaStore.lastLon
                if (la != null && lo != null) mapView.controller.animateTo(GeoPoint(la, lo))
            }) { Text("من") }
        }
        Gap(6)
        Text(
            (if (NavaStore.tracking) "🔴 در حال ثبت · " else "⚪ متوقف · ") +
                "نقطه: ${fa(NavaStore.trackPoints.size)} · پرواز: ${fa(flights.size)} · رویداد: ${fa(NavaStore.events.size)}"
        )
        Gap(6)
        AndroidView(
            factory = { mapView },
            modifier = Modifier.fillMaxWidth().height(440.dp).clip(RoundedCornerShape(24.dp)),
            update = { m ->
                m.overlays.clear()
                val pts = NavaStore.trackPoints.map { GeoPoint(it.first, it.second) }
                if (pts.size > 1) {
                    val line = Polyline()
                    line.setPoints(pts)
                    line.outlinePaint.color = android.graphics.Color.parseColor("#C97B63")
                    line.outlinePaint.strokeWidth = 8f
                    m.overlays.add(line)
                }
                for (f in flights) {
                    val mk = Marker(m)
                    mk.position = GeoPoint(f.lat, f.lon)
                    mk.title = "✈ ${f.call}"
                    mk.snippet = "ارتفاع ${f.alt.roundToInt()} m · سرعت ${(f.speed * 3.6).roundToInt()} km/h"
                    m.overlays.add(mk)
                }
                for (e in NavaStore.events.toList()) {
                    val mk = Marker(m)
                    mk.position = GeoPoint(e.lat, e.lon)
                    mk.title = (if (e.kind == "photo") "📷 " else "🔔 ") + e.title
                    m.overlays.add(mk)
                }
                m.invalidate()
            }
        )
    }
}
