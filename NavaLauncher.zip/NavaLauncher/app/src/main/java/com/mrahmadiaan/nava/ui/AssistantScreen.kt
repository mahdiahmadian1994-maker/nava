package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class Chat(val user: Boolean, val text: String, val route: String? = null)

private fun answer(q: String): Chat {
    val t = q.lowercase()
    fun has(vararg k: String) = k.any { t.contains(it) }
    return when {
        has("هوا", "دما", "باران", "برف", "weather", "rain", "temp") -> Chat(false, tr("هواشناسی را باز می‌کنم.", "Opening weather."), "weather")
        has("تقویم", "یادآور", "تاریخ", "برنامه", "calendar", "schedule", "remind") -> Chat(false, tr("تقویم و اسکجولر.", "Calendar & schedule."), "calendar")
        has("پیام", "واتساپ", "تلگرام", "اینستا", "message", "whatsapp", "telegram") -> Chat(false, tr("پیام‌های دریافتی.", "Your messages."), "messages")
        has("سلامت", "قدم", "وزن", "bmi", "ضربان", "health", "steps", "heart") -> Chat(false, tr("بخش سلامت.", "Health."), "health")
        has("بازار", "طلا", "بیت", "دلار", "نفت", "market", "gold", "bitcoin", "oil") -> Chat(false, tr("بازارها.", "Markets."), "markets")
        has("موزیک", "آهنگ", "پخش", "music", "song", "play") -> Chat(false, tr("موزیک‌پلیر.", "Music player."), "music")
        has("آمار", "مصرف", "اینترنت", "usage", "data") -> Chat(false, tr("آمار استفاده.", "Usage stats."), "usage")
        has("مسیر", "نقشه", "پرواز", "هواپیما", "map", "track", "flight") -> Chat(false, tr("ترکینگ و نقشه.", "Tracking & map."), "tracking")
        has("تنظیم", "رنگ", "پالت", "آپدیت", "زبان", "setting", "color", "update", "language") -> Chat(false, tr("تنظیمات.", "Settings."), "settings")
        else -> Chat(false, tr("متوجه نشدم. بگویید: هوا، تقویم، پیام، سلامت، بازار، موزیک، آمار یا مسیر.", "I didn't get that. Try: weather, calendar, messages, health, markets, music, usage or map."))
    }
}

@Composable
fun AssistantScreen(nav: NavController) {
    val chat = remember { mutableStateListOf(Chat(false, tr("سلام! چه کمکی از من برمی‌آید؟", "Hi! How can I help?"))) }
    var input by remember { mutableStateOf("") }

    ScreenFrame(tr("دستیار", "Assistant"), nav, scroll = false) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(chat.toList()) { c ->
                GlassCard(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    onClick = if (c.route != null) ({ nav.navigate(c.route) }) else null
                ) {
                    Text((if (c.user) tr("شما: ", "You: ") else tr("نوا: ", "Nava: ")) + c.text)
                    if (c.route != null) Text(tr("برای باز کردن لمس کنید", "Tap to open"))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, singleLine = true,
                placeholder = { Text(tr("پیام شما...", "Your message...")) }, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                if (input.isNotBlank()) {
                    val q = input.trim()
                    chat.add(Chat(true, q))
                    chat.add(answer(q))
                    input = ""
                }
            }) { Text(tr("ارسال", "Send")) }
        }
    }
}
