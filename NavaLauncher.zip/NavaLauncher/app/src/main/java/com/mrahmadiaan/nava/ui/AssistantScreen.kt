package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class Chat(val user: Boolean, val text: String, val route: String? = null)

private fun answer(q: String): Chat {
    val t = q.lowercase()
    fun has(vararg k: String) = k.any { t.contains(it) }
    return when {
        has("هوا", "دما", "باران", "برف") -> Chat(false, "هواشناسی را باز می‌کنم.", "weather")
        has("تقویم", "یادآور", "تاریخ", "چک") -> Chat(false, "تقویم و چک‌لیست‌ها.", "calendar")
        has("پیام", "واتساپ", "تلگرام", "اینستا") -> Chat(false, "پیام‌های دریافتی.", "messages")
        has("سلامت", "قدم", "وزن", "bmi", "ضربان") -> Chat(false, "بخش سلامت.", "health")
        has("بازار", "طلا", "بیت", "دلار", "نفت") -> Chat(false, "بازارها.", "markets")
        has("موزیک", "آهنگ", "پخش") -> Chat(false, "موزیک‌پلیر.", "music")
        has("آمار", "مصرف", "اینترنت") -> Chat(false, "آمار استفاده.", "usage")
        has("مسیر", "نقشه", "پرواز", "هواپیما") -> Chat(false, "ترکینگ و نقشه.", "tracking")
        has("تنظیم", "رنگ", "پالت", "آپدیت") -> Chat(false, "تنظیمات.", "settings")
        else -> Chat(false, "متوجه نشدم. بگویید: هوا، تقویم، پیام، سلامت، بازار، موزیک، آمار یا مسیر.")
    }
}

@Composable
fun AssistantScreen(nav: NavController) {
    val chat = remember { mutableStateListOf(Chat(false, "سلام! چه کمکی از من برمی‌آید؟")) }
    var input by remember { mutableStateOf("") }

    ScreenFrame("دستیار", nav, scroll = false) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(chat.toList()) { c ->
                GlassCard(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    onClick = if (c.route != null) ({ nav.navigate(c.route) }) else null
                ) {
                    Text((if (c.user) "شما: " else "نوا: ") + c.text)
                    if (c.route != null) Text("برای باز کردن لمس کنید ←")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, singleLine = true,
                placeholder = { Text("پیام شما...") }, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                if (input.isNotBlank()) {
                    val q = input.trim()
                    chat.add(Chat(true, q))
                    val a = answer(q)
                    chat.add(a)
                    input = ""
                }
            }) { Text("ارسال") }
        }
    }
}
