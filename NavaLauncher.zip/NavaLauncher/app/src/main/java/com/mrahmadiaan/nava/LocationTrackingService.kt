package com.mrahmadiaan.nava

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class LocationTrackingService : Service() {
    private var client: FusedLocationProviderClient? = null
    private var observer: ContentObserver? = null
    private var lastPhoto = 0L

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (l in result.locations) NavaStore.addPoint(l.latitude, l.longitude)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "nava_track"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Tracking", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Nava Launcher")
            .setContentText("در حال ثبت مسیر حرکت")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (client == null) {
            val c = LocationServices.getFusedLocationProviderClient(this)
            client = c
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
                .setMinUpdateDistanceMeters(5f)
                .build()
            try {
                c.requestLocationUpdates(req, callback, Looper.getMainLooper())
            } catch (e: SecurityException) {
                stopSelf()
                return START_NOT_STICKY
            }
            val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    val now = System.currentTimeMillis()
                    if (now - lastPhoto > 5000) {
                        lastPhoto = now
                        NavaStore.addEventHere("photo", "عکس جدید")
                    }
                }
            }
            observer = obs
            contentResolver.registerContentObserver(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs
            )
            NavaStore.tracking = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        client?.removeLocationUpdates(callback)
        client = null
        observer?.let { contentResolver.unregisterContentObserver(it) }
        observer = null
        NavaStore.tracking = false
        super.onDestroy()
    }
}
