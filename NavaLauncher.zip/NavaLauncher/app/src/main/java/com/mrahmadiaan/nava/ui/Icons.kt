package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Ico(kind: String, color: Color = LocalContentColor.current, sz: Dp = 24.dp, modifier: Modifier = Modifier) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(modifier.size(sz)) {
        val st = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        scale(this.size.minDimension / 24f, pivot = Offset.Zero) {
            fun ln(a: Float, b: Float, c: Float, d: Float) =
                drawLine(color, Offset(a, b), Offset(c, d), 1.8f, StrokeCap.Round)
            fun ring(x: Float, y: Float, r: Float) = drawCircle(color, r, Offset(x, y), style = st)
            fun dot(x: Float, y: Float, r: Float) = drawCircle(color, r, Offset(x, y))
            fun box(x: Float, y: Float, w: Float, h: Float, r: Float) =
                drawRoundRect(color, Offset(x, y), Size(w, h), CornerRadius(r, r), style = st)
            fun pth(fill: Boolean = false, b: Path.() -> Unit) =
                drawPath(Path().apply(b), color, style = if (fill) Fill else st)
            fun cloud() = pth {
                moveTo(7f, 16f)
                cubicTo(4f, 16f, 3f, 13.5f, 4.5f, 11.5f)
                cubicTo(5.5f, 10f, 7f, 10f, 8f, 10.5f)
                cubicTo(8.5f, 7.5f, 11f, 6f, 13.5f, 6.5f)
                cubicTo(16f, 7f, 17f, 9f, 17f, 10.5f)
                cubicTo(19.5f, 10.5f, 21f, 12f, 21f, 13.5f)
                cubicTo(21f, 15f, 19.5f, 16f, 18f, 16f)
                lineTo(7f, 16f)
            }
            when (kind) {
                "map" -> {
                    pth {
                        moveTo(12f, 21f)
                        cubicTo(8f, 17.5f, 5f, 13.5f, 5f, 9.5f)
                        cubicTo(5f, 5.6f, 8.1f, 2.5f, 12f, 2.5f)
                        cubicTo(15.9f, 2.5f, 19f, 5.6f, 19f, 9.5f)
                        cubicTo(19f, 13.5f, 16f, 17.5f, 12f, 21f)
                        close()
                    }
                    ring(12f, 9.5f, 2.5f)
                }
                "calendar" -> { box(4f, 5f, 16f, 15f, 3f); ln(4f, 10f, 20f, 10f); ln(8f, 3f, 8f, 7f); ln(16f, 3f, 16f, 7f) }
                "chat" -> { box(4f, 4f, 16f, 12f, 3f); pth { moveTo(9f, 16f); lineTo(8f, 20f); lineTo(13f, 16f) } }
                "heart" -> pth {
                    moveTo(12f, 20f)
                    cubicTo(5f, 15f, 3f, 11f, 3f, 8.5f)
                    cubicTo(3f, 6f, 5f, 4.5f, 7f, 4.5f)
                    cubicTo(9f, 4.5f, 11f, 5.5f, 12f, 7.5f)
                    cubicTo(13f, 5.5f, 15f, 4.5f, 17f, 4.5f)
                    cubicTo(19f, 4.5f, 21f, 6f, 21f, 8.5f)
                    cubicTo(21f, 11f, 19f, 15f, 12f, 20f)
                }
                "sun" -> {
                    ring(12f, 12f, 4f)
                    for (i in 0 until 8) {
                        val a = i * 0.7853982f
                        ln(12f + 6.5f * cos(a), 12f + 6.5f * sin(a), 12f + 9f * cos(a), 12f + 9f * sin(a))
                    }
                }
                "cloud" -> cloud()
                "rain" -> { cloud(); ln(8f, 18.5f, 7f, 21.5f); ln(12f, 18.5f, 11f, 21.5f); ln(16f, 18.5f, 15f, 21.5f) }
                "snow" -> { cloud(); dot(8f, 20f, 1f); dot(12f, 21f, 1f); dot(16f, 20f, 1f) }
                "bolt" -> { cloud(); pth { moveTo(12.5f, 16.5f); lineTo(10.5f, 20f); lineTo(13.5f, 20f); lineTo(11.5f, 23f) } }
                "fog" -> { ln(4f, 8f, 20f, 8f); ln(6f, 12f, 18f, 12f); ln(4f, 16f, 20f, 16f) }
                "wind" -> {
                    pth { moveTo(3f, 9f); lineTo(14f, 9f); cubicTo(17f, 9f, 17.5f, 5f, 14.5f, 5f) }
                    pth { moveTo(3f, 13f); lineTo(18f, 13f); cubicTo(21f, 13f, 21.5f, 17f, 18.5f, 17f) }
                    ln(3f, 17f, 10f, 17f)
                }
                "compass" -> {
                    ring(12f, 12f, 9f)
                    pth(true) { moveTo(15.5f, 8.5f); lineTo(13.5f, 13.5f); lineTo(8.5f, 15.5f); lineTo(10.5f, 10.5f); close() }
                }
                "moon" -> pth {
                    moveTo(20f, 13f)
                    cubicTo(15f, 16.5f, 8f, 13.5f, 8f, 7.5f)
                    cubicTo(8f, 6f, 8.5f, 4.5f, 9.5f, 3.5f)
                    cubicTo(5f, 4.5f, 3f, 9f, 4.5f, 13.5f)
                    cubicTo(6f, 18f, 11f, 20.5f, 15.5f, 19f)
                    cubicTo(17.5f, 18.4f, 19.2f, 16.2f, 20f, 13f)
                }
                "chart" -> { ln(6f, 19f, 6f, 13f); ln(12f, 19f, 12f, 6f); ln(18f, 19f, 18f, 10f); ln(3f, 21f, 21f, 21f) }
                "music" -> { ln(9f, 17f, 9f, 5f); ln(9f, 5f, 19f, 3f); ln(19f, 3f, 19f, 15f); ring(7f, 17f, 2.5f); ring(17f, 15f, 2.5f) }
                "pie" -> { ring(12f, 12f, 8f); ln(12f, 12f, 12f, 4f); ln(12f, 12f, 18.5f, 16f) }
                "bot" -> { box(5f, 8f, 14f, 11f, 4f); ln(12f, 4f, 12f, 8f); dot(12f, 3.5f, 1.2f); dot(9.5f, 13.5f, 1.2f); dot(14.5f, 13.5f, 1.2f) }
                "gear" -> {
                    ring(12f, 12f, 3f); ring(12f, 12f, 7f)
                    for (i in 0 until 8) {
                        val a = i * 0.7853982f
                        ln(12f + 7f * cos(a), 12f + 7f * sin(a), 12f + 9.5f * cos(a), 12f + 9.5f * sin(a))
                    }
                }
                "back" -> if (rtl) pth { moveTo(9f, 5f); lineTo(16f, 12f); lineTo(9f, 19f) } else pth { moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) }
                "play" -> pth(true) { moveTo(8f, 5f); lineTo(19f, 12f); lineTo(8f, 19f); close() }
                "pause" -> {
                    drawRect(color, Offset(7f, 5f), Size(3.5f, 14f))
                    drawRect(color, Offset(13.5f, 5f), Size(3.5f, 14f))
                }
                "next" -> { pth(true) { moveTo(6f, 5f); lineTo(16f, 12f); lineTo(6f, 19f); close() }; ln(19f, 5f, 19f, 19f) }
                "prev" -> { pth(true) { moveTo(18f, 5f); lineTo(8f, 12f); lineTo(18f, 19f); close() }; ln(5f, 5f, 5f, 19f) }
                "shuffle" -> {
                    pth { moveTo(3f, 7f); lineTo(7f, 7f); cubicTo(12f, 7f, 11f, 17f, 16f, 17f); lineTo(20f, 17f) }
                    pth { moveTo(3f, 17f); lineTo(7f, 17f); cubicTo(12f, 17f, 11f, 7f, 16f, 7f); lineTo(20f, 7f) }
                }
                "repeat" -> { box(4f, 7f, 16f, 10f, 5f); pth { moveTo(17f, 4f); lineTo(20f, 7f); lineTo(17f, 10f) } }
                "search" -> { ring(11f, 11f, 6f); ln(16f, 16f, 20f, 20f) }
                "plus" -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
                "close" -> { ln(6f, 6f, 18f, 18f); ln(18f, 6f, 6f, 18f) }
                "check" -> pth { moveTo(5f, 12f); lineTo(10f, 17f); lineTo(19f, 7f) }
                "trash" -> { box(6f, 7f, 12f, 13f, 2f); ln(4f, 7f, 20f, 7f); ln(10f, 4f, 14f, 4f) }
                "clock" -> { ring(12f, 12f, 8f); ln(12f, 7f, 12f, 12f); ln(12f, 12f, 15.5f, 14f) }
                "speed" -> { ring(12f, 12f, 9f); ln(12f, 12f, 16f, 8f) }
                "battery" -> { box(3f, 8f, 16f, 9f, 2f); ln(21f, 11f, 21f, 14f) }
                "chev_down" -> pth { moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f) }
                "chev_up" -> pth { moveTo(6f, 15f); lineTo(12f, 9f); lineTo(18f, 15f) }
                "lang" -> {
                    ring(12f, 12f, 9f); ln(3f, 12f, 21f, 12f)
                    pth { moveTo(12f, 3f); cubicTo(8f, 7f, 8f, 17f, 12f, 21f) }
                    pth { moveTo(12f, 3f); cubicTo(16f, 7f, 16f, 17f, 12f, 21f) }
                }
                "lock" -> { box(5f, 11f, 14f, 9f, 2.5f); pth { moveTo(8f, 11f); lineTo(8f, 8f); cubicTo(8f, 3f, 16f, 3f, 16f, 8f); lineTo(16f, 11f) } }
                "image" -> { box(4f, 5f, 16f, 14f, 3f); dot(9f, 10f, 1.5f); pth { moveTo(5f, 17f); lineTo(10f, 13f); lineTo(14f, 16f); lineTo(19f, 11f) } }
                "wifi" -> {
                    for (r in listOf(3f, 6f, 9f)) {
                        drawArc(color, 225f, 90f, false, Offset(12f - r, 17f - r), Size(2 * r, 2 * r), style = st)
                    }
                    dot(12f, 18.5f, 1f)
                }
                else -> ring(12f, 12f, 8f)
            }
        }
    }
}
