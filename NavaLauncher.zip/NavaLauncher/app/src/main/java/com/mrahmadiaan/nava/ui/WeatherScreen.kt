package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.math.roundToInt

@Composable
fun WeatherScreen(nav: NavController) {
    val ctx = LocalContext.current
    var w by remember { mutableStateOf<Weather?>(null) }
    var loading by remember { mutableStateOf(true) }
    var loc by remember { mutableStateOf(35.6892 to 51.3890) }

    LaunchedEffect(Unit) {
        loc = bestLocation(ctx)
        w = fetchWeather(loc.first, loc.second)
        loading = false
    }

    ScreenFrame("هواشناسی", nav) {
        val cur = w
        if (cur == null) {
            Text(if (loading) "در حال دریافت..." else "دریافت اطلاعات ممکن نشد (اینترنت را بررسی کنید)")
        } else {
            val info = weatherInfo(cur.code)
            val panels = listOf(
                info.first to info.second,
                "🌡️" to "دما: ${fa(cur.temp.roundToInt())}°C",
                "💨" to "باد: ${fa(cur.wind.roundToInt())} km/h",
                "🧭" to "جهت باد: ${fa(cur.dir.roundToInt())}°",
                (if (cur.isDay) "🌞" else "🌙") to (if (cur.isDay) "روز" else "شب"),
                "📍" to "${fa("%.2f".format(loc.first))}, ${fa("%.2f".format(loc.second))}"
            )
            for (pair in panels.chunked(2)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (p in pair) {
                        GlassCard(Modifier.weight(1f).height(120.dp)) {
                            Text(p.first, fontSize = 34.sp)
                            Text(p.second, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Gap(10)
            }
            Text("منبع: Open-Meteo", fontSize = 11.sp)
        }
    }
}
