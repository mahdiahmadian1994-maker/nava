package com.mrahmadiaan.nava.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.math.roundToInt

private class Panel(val icon: String, val title: String, val value: String, val tint: Int)

@Composable
fun WeatherScreen(nav: NavController) {
    val ctx = LocalContext.current
    var w by remember { mutableStateOf<Weather?>(null) }
    var loading by remember { mutableStateOf(true) }
    var loc by remember { mutableStateOf(35.6892 to 51.3890) }

    LaunchedEffect(Unit) {
        loc = bestLocation(ctx)
        w = fetchWeather(loc.first, loc.second)
        loading = false
    }

    ScreenFrame(tr("هواشناسی", "Weather"), nav) {
        val cur = w
        if (cur == null) {
            Text(
                if (loading) tr("در حال دریافت...", "Loading...")
                else tr("دریافت اطلاعات ممکن نشد (اینترنت را بررسی کنید)", "Could not load (check internet)")
            )
        } else {
            val info = weatherInfo(cur.code)
            val panels = listOf(
                Panel(info.first, tr("وضعیت", "Condition"), info.second, 4),
                Panel("sun", tr("دما", "Temperature"), fa(cur.temp.roundToInt()) + "°C", 2),
                Panel("wind", tr("باد", "Wind"), fa(cur.wind.roundToInt()) + " km/h", 0),
                Panel("compass", tr("جهت باد", "Direction"), fa(cur.dir.roundToInt()) + "°", 1),
                Panel(if (cur.isDay) "sun" else "moon", tr("زمان", "Time of day"), if (cur.isDay) tr("روز", "Day") else tr("شب", "Night"), 1),
                Panel("map", tr("مختصات", "Location"), fa("%.2f".format(loc.first)) + ", " + fa("%.2f".format(loc.second)), 0)
            )
            val pal = PaletteState.colors
            for (pair in panels.chunked(2)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (p in pair) {
                        GlassCard(Modifier.weight(1f).height(130.dp)) {
                            Ico(p.icon, pal[p.tint], 36.dp)
                            Gap(6)
                            Text(p.title, fontSize = 11.sp)
                            Text(p.value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }
                    }
                }
                Gap(10)
            }
            Text(tr("منبع: Open-Meteo", "Source: Open-Meteo"), fontSize = 11.sp)
        }
    }
}
