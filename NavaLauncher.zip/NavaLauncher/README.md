# Nava Launcher
طراحی و توسعه: Mr.ahmadiaan

۱. همه فایل‌های این پروژه را در یک مخزن (Repository) گیت‌هاب آپلود کنید.
۲. تب Actions → Build APK → بعد از اتمام، فایل NavaLauncher-APK را دانلود و نصب کنید.
