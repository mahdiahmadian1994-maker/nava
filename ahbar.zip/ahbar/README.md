# احبر (Ahbar)
دستیار صوتی فارسی. مرحله A: برنامه‌ی سلام + ساخت خودکار APK.

## روش گوشی (بدون git)
1. در github.com یک مخزن جدید به نام `ahbar` بساز (Public).
2. Add file ← Upload files ← فایل `ahbar.zip` را آپلود کن ← Commit.
3. Add file ← Create new file، اسم: `.github/workflows/build-apk.yml` و متن همین فایل را از داخل زیپ پیست کن ← Commit.
4. تب Actions: بعد از ۸-۱۲ دقیقه تیک سبز.
5. سمت راست صفحه‌ی مخزن، Releases ← آخرین مورد ← Assets ← `app-release.apk`.

## روش کامپیوتر (git)
```
cd ahbar
git init
git add .
git commit -m "stage A"
git branch -M main
git remote add origin https://github.com/USERNAME/ahbar.git
git push -u origin main
```
(USERNAME را با نام کاربری خودت عوض کن؛ مخزن خالی `ahbar` باید از قبل ساخته شده باشد.)

## نصب روی گوشی
APK را دانلود کن، باز کن، اگر پرسید «Install unknown apps» را برای مرورگر/فایل‌ها اجازه بده.
